import { useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { ShoppingBag } from "lucide-react";
import CartItem from "@/components/cart-item";
import { useLocation } from "wouter";

export default function OrderSummary() {
  const cart = useCart();
  const [, setLocation] = useLocation();
  
  const handleCheckout = () => {
    setLocation("/checkout");
  };

  if (cart.getTotalItems() === 0) {
    return (
      <div className="bg-white rounded-xl shadow-md p-5 sticky top-28">
        <h2 className="text-xl font-bold mb-4">Your Order</h2>
        <div className="text-center py-8">
          <div className="text-4xl text-neutral-300 mb-3">
            <ShoppingBag className="mx-auto" />
          </div>
          <p className="text-neutral-500 mb-4">Your cart is empty</p>
          <p className="text-sm text-neutral-500">Add items from a restaurant to start your order</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-md p-5 sticky top-28">
      <h2 className="text-xl font-bold mb-4">Your Order</h2>
      
      <div>
        <div className="text-sm font-medium text-neutral-700 mb-3">
          Order from: <span className="text-primary">{cart.restaurant?.name}</span>
        </div>
        
        <div className="space-y-4 mb-6 max-h-64 overflow-y-auto scrollbar-hide">
          {cart.items.map((item) => (
            <CartItem key={item.menuItemId} item={item} />
          ))}
        </div>
        
        <div className="border-t pt-4 space-y-2">
          <div className="flex justify-between text-neutral-700">
            <span>Subtotal</span>
            <span>${cart.getSubtotal().toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-neutral-700">
            <span>Delivery Fee</span>
            <span>Free</span>
          </div>
          <div className="flex justify-between text-neutral-700">
            <span>Tax</span>
            <span>${cart.getTax().toFixed(2)}</span>
          </div>
          <div className="flex justify-between font-bold text-lg mt-3">
            <span>Total</span>
            <span>${cart.getTotal().toFixed(2)}</span>
          </div>
        </div>
        
        <Button
          onClick={handleCheckout}
          className="w-full bg-primary hover:bg-red-600 text-white font-medium py-3 px-4 rounded-lg mt-6 transition"
        >
          Proceed to Checkout
        </Button>
      </div>
    </div>
  );
}
