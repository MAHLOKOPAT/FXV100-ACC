import { useState, useRef, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

type CategoryFilterProps = {
  categories: string[];
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
};

export default function CategoryFilter({ 
  categories, 
  selectedCategory, 
  onSelectCategory 
}: CategoryFilterProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [showLeftScroll, setShowLeftScroll] = useState(false);
  const [showRightScroll, setShowRightScroll] = useState(false);

  // Check if scrolling controls should be shown
  const checkScrollControls = () => {
    if (!scrollRef.current) return;
    
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    setShowLeftScroll(scrollLeft > 0);
    setShowRightScroll(scrollLeft < scrollWidth - clientWidth - 5); // 5px buffer
  };

  // Initialize scroll controls on mount and when categories change
  useEffect(() => {
    checkScrollControls();
    window.addEventListener('resize', checkScrollControls);
    return () => window.removeEventListener('resize', checkScrollControls);
  }, [categories]);

  // Handle scrolling
  const scroll = (direction: 'left' | 'right') => {
    if (!scrollRef.current) return;
    
    const scrollAmount = 200;
    const currentScroll = scrollRef.current.scrollLeft;
    
    scrollRef.current.scrollTo({
      left: direction === 'left' 
        ? currentScroll - scrollAmount 
        : currentScroll + scrollAmount,
      behavior: 'smooth'
    });
    
    // Update scroll controls after scrolling
    setTimeout(checkScrollControls, 300);
  };

  return (
    <div className="bg-white sticky top-16 z-40 shadow-sm">
      <div className="container mx-auto px-4 relative">
        {/* Left scroll button */}
        {showLeftScroll && (
          <button 
            onClick={() => scroll('left')}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full p-1 shadow-md"
          >
            <ChevronLeft className="h-5 w-5 text-neutral-700" />
          </button>
        )}
        
        {/* Categories */}
        <div 
          ref={scrollRef}
          className="overflow-x-auto scrollbar-hide"
          onScroll={checkScrollControls}
        >
          <div className="flex py-4 space-x-4 min-w-max">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => onSelectCategory(category)}
                className={`px-4 py-2 rounded-full font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === category
                    ? "bg-primary text-white"
                    : "bg-neutral-100 text-neutral-700 hover:bg-neutral-200"
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        
        {/* Right scroll button */}
        {showRightScroll && (
          <button 
            onClick={() => scroll('right')}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full p-1 shadow-md"
          >
            <ChevronRight className="h-5 w-5 text-neutral-700" />
          </button>
        )}
      </div>
    </div>
  );
}
