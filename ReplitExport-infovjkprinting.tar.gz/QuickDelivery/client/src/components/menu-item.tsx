import { Plus } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart";
import { type MenuItem } from "@shared/schema";

type MenuItemProps = {
  item: MenuItem;
  restaurantId: number;
  restaurantName: string;
};

export default function MenuItemCard({ item, restaurantId, restaurantName }: MenuItemProps) {
  const { addItem } = useCart();
  const [isHovered, setIsHovered] = useState(false);

  const handleAddToCart = () => {
    addItem(
      {
        menuItemId: item.id,
        name: item.name,
        price: item.price,
        quantity: 1
      },
      restaurantId,
      restaurantName
    );
  };

  return (
    <div 
      className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow flex"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="p-4 flex-1">
        <h4 className="font-bold text-lg mb-1">{item.name}</h4>
        <p className="text-neutral-600 text-sm mb-2">{item.description}</p>
        <p className="font-medium">${item.price.toFixed(2)}</p>
      </div>
      <div className="relative min-w-[120px]">
        <img 
          src={item.image} 
          alt={item.name} 
          className="h-full w-full object-cover transition-opacity"
          style={{ opacity: isHovered ? 0.9 : 1 }}
        />
        <Button
          onClick={handleAddToCart}
          className="absolute bottom-2 right-2 bg-white rounded-full p-2 shadow-md hover:bg-neutral-100 transition"
          size="icon"
          variant="outline"
        >
          <Plus className="h-4 w-4 text-primary" />
        </Button>
      </div>
    </div>
  );
}
