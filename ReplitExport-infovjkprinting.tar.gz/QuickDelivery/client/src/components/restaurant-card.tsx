import { Link } from "wouter";
import { Star, Bike, MapPin } from "lucide-react";
import { type Restaurant } from "@shared/schema";

type RestaurantCardProps = {
  restaurant: Restaurant;
};

export default function RestaurantCard({ restaurant }: RestaurantCardProps) {
  return (
    <Link href={`/restaurant/${restaurant.id}`} className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow cursor-pointer block">
      <div className="relative">
        <img 
          src={restaurant.image} 
          alt={`${restaurant.name} restaurant`} 
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-3 right-3 bg-white py-1 px-2 rounded-lg text-sm font-medium text-neutral-800">
          {restaurant.deliveryTime}
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold text-lg mb-1">{restaurant.name}</h3>
        <div className="flex items-center text-sm mb-2">
          <span className="flex items-center text-[#FFC043] mr-2">
            <Star className="w-4 h-4 mr-1 fill-current" />
            {restaurant.rating.toFixed(1)}
          </span>
          <span className="text-neutral-600">
            {restaurant.priceLevel} • {restaurant.categories.join(", ")}
          </span>
        </div>
        <div className="flex items-center text-sm text-neutral-600 mb-2">
          <span className="flex items-center">
            <Bike className="w-4 h-4 mr-1" />
            {restaurant.deliveryFee}
          </span>
        </div>
        <div className="flex items-center text-sm text-neutral-600">
          <span className="flex items-center">
            <MapPin className="w-4 h-4 mr-1" />
            {restaurant.address}, {restaurant.city}
          </span>
        </div>
      </div>
    </Link>
  );
}
