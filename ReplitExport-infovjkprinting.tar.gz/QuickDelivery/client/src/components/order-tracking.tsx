import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { CheckCircle, HandPlatter, Bike } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { Order } from "@shared/schema";

type OrderTrackingProps = {
  orderId: number;
};

export default function OrderTracking({ orderId }: OrderTrackingProps) {
  const [, setLocation] = useLocation();
  const [orderNumber] = useState(`FD${Math.floor(10000 + Math.random() * 90000)}`);
  const [estimatedDelivery] = useState("30-45 minutes");

  const { data: order, isLoading } = useQuery<Order | undefined>({
    queryKey: [`/api/orders/${orderId}`],
    refetchInterval: 30000, // Refetch every 30 seconds
  });

  // Auto-advance the order status for demonstration
  useEffect(() => {
    if (order && order.status === "pending") {
      // After 5 seconds, update to confirmed
      const timer = setTimeout(async () => {
        try {
          await fetch(`/api/orders/${orderId}/status`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ status: "confirmed" }),
          });
        } catch (error) {
          console.error("Error updating order status:", error);
        }
      }, 5000);
      
      return () => clearTimeout(timer);
    }
    
    if (order && order.status === "confirmed") {
      // After 10 seconds, update to preparing
      const timer = setTimeout(async () => {
        try {
          await fetch(`/api/orders/${orderId}/status`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ status: "preparing" }),
          });
        } catch (error) {
          console.error("Error updating order status:", error);
        }
      }, 10000);
      
      return () => clearTimeout(timer);
    }
    
    if (order && order.status === "preparing") {
      // After 15 seconds, update to delivering
      const timer = setTimeout(async () => {
        try {
          await fetch(`/api/orders/${orderId}/status`, {
            method: "PATCH",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ status: "delivering" }),
          });
        } catch (error) {
          console.error("Error updating order status:", error);
        }
      }, 15000);
      
      return () => clearTimeout(timer);
    }
  }, [order, orderId]);

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
        <p className="mt-4 text-neutral-600">Loading order details...</p>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="text-center py-8">
        <div className="text-5xl text-red-500 mb-4">❗</div>
        <h2 className="text-2xl font-bold mb-2">Order Not Found</h2>
        <p className="text-neutral-600 mb-6">We couldn't find your order. Please try again.</p>
        <Button onClick={() => setLocation("/")} className="bg-primary hover:bg-red-600 text-white">
          Return Home
        </Button>
      </div>
    );
  }

  return (
    <div className="text-center">
      <div className="text-5xl text-success mb-4">
        <CheckCircle className="w-16 h-16 text-[#28A745] mx-auto" />
      </div>
      <h2 className="text-2xl font-bold mb-2">Order Placed Successfully!</h2>
      <p className="text-neutral-600 mb-4">Your order has been received and is being prepared.</p>
      
      <div className="mb-6">
        <div className="bg-neutral-100 rounded-lg p-4">
          <div className="flex justify-between mb-2">
            <span className="font-medium">Order Number:</span>
            <span>#{orderNumber}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="font-medium">Estimated Delivery:</span>
            <span>{estimatedDelivery}</span>
          </div>
        </div>
      </div>
      
      <div className="mb-6">
        <div className="relative pt-4">
          <div className="flex mb-2">
            <div className={`flex items-center justify-center w-10 h-10 ${
              order.status === "confirmed" || order.status === "preparing" || order.status === "delivering" || order.status === "delivered"
                ? "bg-[#28A745] text-white"
                : "bg-neutral-200 text-neutral-700"
              } rounded-full shrink-0`}>
              <CheckCircle className="w-5 h-5" />
            </div>
            <div className="ml-3 text-left">
              <h3 className="font-medium">Order Confirmed</h3>
              <p className="text-sm text-neutral-600">Your order has been received</p>
            </div>
          </div>
          <div className="absolute left-5 top-0 h-full">
            <div className="h-full w-0.5 bg-neutral-200"></div>
          </div>
        </div>
        
        <div className="relative pt-4">
          <div className="flex mb-2">
            <div className={`flex items-center justify-center w-10 h-10 ${
              order.status === "preparing" || order.status === "delivering" || order.status === "delivered"
                ? "bg-[#28A745] text-white"
                : "bg-neutral-200 text-neutral-700"
              } rounded-full shrink-0`}>
              <HandPlatter className="w-5 h-5" />
            </div>
            <div className="ml-3 text-left">
              <h3 className="font-medium">Preparing</h3>
              <p className="text-sm text-neutral-600">HandPlatter is preparing your food</p>
            </div>
          </div>
          <div className="absolute left-5 top-0 h-full">
            <div className="h-full w-0.5 bg-neutral-200"></div>
          </div>
        </div>
        
        <div className="relative pt-4">
          <div className="flex">
            <div className={`flex items-center justify-center w-10 h-10 ${
              order.status === "delivering" || order.status === "delivered"
                ? "bg-[#28A745] text-white"
                : "bg-neutral-200 text-neutral-700"
              } rounded-full shrink-0`}>
              <Bike className="w-5 h-5" />
            </div>
            <div className="ml-3 text-left">
              <h3 className="font-medium">On the way</h3>
              <p className="text-sm text-neutral-600">Your order is on its way to you</p>
            </div>
          </div>
        </div>
      </div>
      
      <Button 
        onClick={() => setLocation("/")} 
        className="w-full px-6 py-3 bg-primary hover:bg-red-600 text-white font-medium rounded-lg transition"
      >
        Back to Home
      </Button>
    </div>
  );
}
