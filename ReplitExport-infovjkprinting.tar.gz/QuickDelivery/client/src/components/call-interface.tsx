import { useState } from "react";
import { useAudio } from "@/lib/audio-context";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { MicIcon, MicOffIcon, Save, Plus, Trash2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import NoiseCancellationVisualizer from "@/components/noise-cancellation-visualizer";

export default function CallInterface() {
  const {
    isStreamActive,
    noiseCancellationLevel,
    echoCancellation,
    autoGainControl,
    presets,
    startStream,
    stopStream,
    saveSettings,
    updateNoiseCancellationLevel,
    toggleEchoCancellation,
    toggleAutoGainControl,
    addPreset,
    deletePreset,
    applyPreset
  } = useAudio();

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [presetName, setPresetName] = useState("");

  const handleAddPreset = async () => {
    if (presetName.trim()) {
      await addPreset(presetName.trim());
      setPresetName("");
      setIsDialogOpen(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4">
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Call Noise Cancellation</CardTitle>
          <CardDescription>
            Improve your call quality by reducing background noise
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="flex justify-center items-center h-40">
            <NoiseCancellationVisualizer isActive={isStreamActive} level={noiseCancellationLevel} />
          </div>
          
          <div className="flex justify-center">
            <Button 
              size="lg" 
              variant={isStreamActive ? "destructive" : "default"}
              onClick={isStreamActive ? stopStream : startStream}
              className="rounded-full w-16 h-16 flex items-center justify-center"
            >
              {isStreamActive ? <MicOffIcon size={24} /> : <MicIcon size={24} />}
            </Button>
          </div>
          
          <Tabs defaultValue="settings" className="mt-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="settings">Settings</TabsTrigger>
              <TabsTrigger value="presets">Presets</TabsTrigger>
            </TabsList>
            
            <TabsContent value="settings" className="space-y-4 mt-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="noise-cancel">Noise Cancellation Level: {noiseCancellationLevel}%</Label>
                </div>
                <Slider 
                  id="noise-cancel"
                  min={0} 
                  max={100} 
                  step={5}
                  value={[noiseCancellationLevel]}
                  onValueChange={(values) => updateNoiseCancellationLevel(values[0])} 
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="echo-cancel">Echo Cancellation</Label>
                  <p className="text-sm text-muted-foreground">
                    Reduces echo during calls
                  </p>
                </div>
                <Switch 
                  id="echo-cancel"
                  checked={echoCancellation}
                  onCheckedChange={toggleEchoCancellation}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-gain">Auto Gain Control</Label>
                  <p className="text-sm text-muted-foreground">
                    Automatically adjusts microphone volume
                  </p>
                </div>
                <Switch 
                  id="auto-gain"
                  checked={autoGainControl}
                  onCheckedChange={toggleAutoGainControl}
                />
              </div>
            </TabsContent>
            
            <TabsContent value="presets" className="mt-4">
              <div className="space-y-3">
                {presets.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    No presets saved. Create one to quickly switch between settings.
                  </div>
                ) : (
                  presets.map((preset) => (
                    <div 
                      key={preset.name} 
                      className="flex items-center justify-between p-3 border rounded-md"
                    >
                      <div>
                        <h4 className="font-medium">{preset.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          Noise: {preset.noiseCancellationLevel}% • 
                          Echo: {preset.echoCancellation ? "On" : "Off"} • 
                          AGC: {preset.autoGainControl ? "On" : "Off"}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => applyPreset(preset)}
                        >
                          Apply
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => deletePreset(preset.name)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
                
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="w-full mt-4" variant="outline">
                      <Plus className="mr-2 h-4 w-4" /> Add New Preset
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Save Current Settings as Preset</DialogTitle>
                      <DialogDescription>
                        Create a preset to quickly switch between different noise cancellation settings.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                      <Label htmlFor="preset-name">Preset Name</Label>
                      <Input 
                        id="preset-name" 
                        value={presetName}
                        onChange={(e) => setPresetName(e.target.value)}
                        placeholder="My Preset"
                        className="mt-2"
                      />
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                        Cancel
                      </Button>
                      <Button onClick={handleAddPreset} disabled={!presetName.trim()}>
                        Save Preset
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        
        <CardFooter>
          <Button className="w-full" onClick={saveSettings}>
            <Save className="mr-2 h-4 w-4" /> Save Settings
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}