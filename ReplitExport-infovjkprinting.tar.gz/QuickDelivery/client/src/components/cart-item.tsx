import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Trash2 } from "lucide-react";
import { useCart } from "@/lib/cart";
import { type CartItem } from "@shared/schema";

type CartItemProps = {
  item: CartItem;
};

export default function CartItemComponent({ item }: CartItemProps) {
  const { updateQuantity, removeItem } = useCart();
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDecrease = () => {
    if (item.quantity > 1) {
      updateQuantity(item.menuItemId, item.quantity - 1);
    } else {
      setIsDeleting(true);
      setTimeout(() => {
        removeItem(item.menuItemId);
      }, 300);
    }
  };

  const handleIncrease = () => {
    updateQuantity(item.menuItemId, item.quantity + 1);
  };

  return (
    <div className={`flex justify-between items-center transition-opacity duration-300 ${isDeleting ? 'opacity-0' : 'opacity-100'}`}>
      <div className="flex items-center">
        <div className="flex items-center border rounded-lg overflow-hidden">
          <Button 
            onClick={handleDecrease}
            variant="ghost"
            size="icon"
            className="px-2 py-1 h-8 bg-neutral-100 hover:bg-neutral-200 rounded-none"
          >
            {item.quantity === 1 ? (
              <Trash2 className="h-3 w-3 text-red-500" />
            ) : (
              <Minus className="h-3 w-3" />
            )}
          </Button>
          <span className="px-3">{item.quantity}</span>
          <Button
            onClick={handleIncrease}
            variant="ghost"
            size="icon"
            className="px-2 py-1 h-8 bg-neutral-100 hover:bg-neutral-200 rounded-none"
          >
            <Plus className="h-3 w-3" />
          </Button>
        </div>
      </div>
      <div className="flex-1 mx-3">
        <div className="font-medium">{item.name}</div>
      </div>
      <div className="font-medium">${(item.price * item.quantity).toFixed(2)}</div>
    </div>
  );
}
