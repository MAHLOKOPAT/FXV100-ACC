import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCart } from "@/lib/cart";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { insertOrderSchema } from "@shared/schema";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

// Extend the order schema with required fields
const checkoutSchema = insertOrderSchema.extend({
  deliveryAddress: z.string().min(5, "Address must be at least 5 characters"),
  deliveryCity: z.string().min(2, "City must be at least 2 characters"),
  deliveryZip: z.string().min(5, "ZIP code must be at least 5 characters"),
  phone: z.string().min(10, "Phone number must be at least 10 characters"),
  paymentMethod: z.enum(["creditCard", "paypal", "cash"], {
    required_error: "Please select a payment method",
  }),
});

type CheckoutFormValues = z.infer<typeof checkoutSchema>;

export default function CheckoutForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const cart = useCart();
  const [, setLocation] = useLocation();

  const form = useForm<CheckoutFormValues>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      restaurantId: cart.restaurant?.id || 0,
      status: "pending",
      totalAmount: cart.getTotal(),
      deliveryAddress: "",
      deliveryCity: "",
      deliveryZip: "",
      phone: "",
      deliveryInstructions: "",
      paymentMethod: "creditCard",
    },
  });

  const onSubmit = async (data: CheckoutFormValues) => {
    if (!cart.restaurant || cart.items.length === 0) {
      toast({
        title: "Error",
        description: "Your cart is empty. Add items before checking out.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsSubmitting(true);
      
      // Update total amount in case it changed
      data.totalAmount = cart.getTotal();
      data.restaurantId = cart.restaurant.id;
      
      // Create order
      const orderResponse = await apiRequest("POST", "/api/orders", data);
      const order = await orderResponse.json();
      
      // Create order items
      const orderItems = cart.items.map((item) => ({
        orderId: order.id,
        menuItemId: item.menuItemId,
        quantity: item.quantity,
        price: item.price,
        name: item.name,
      }));
      
      await apiRequest("POST", `/api/orders/${order.id}/items`, orderItems);
      
      // Clear cart and redirect to confirmation page
      cart.clearCart();
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      
      setLocation(`/order-confirmation/${order.id}`);
    } catch (error) {
      console.error("Error placing order:", error);
      toast({
        title: "Error",
        description: "There was a problem placing your order. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <h3 className="text-lg font-medium mb-4">Delivery Information</h3>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="deliveryAddress">Street Address</Label>
            <Input
              id="deliveryAddress"
              placeholder="123 Main St"
              {...form.register("deliveryAddress")}
              className="mt-1"
            />
            {form.formState.errors.deliveryAddress && (
              <p className="text-sm text-red-500 mt-1">
                {form.formState.errors.deliveryAddress.message}
              </p>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="deliveryCity">City</Label>
              <Input
                id="deliveryCity"
                placeholder="City"
                {...form.register("deliveryCity")}
                className="mt-1"
              />
              {form.formState.errors.deliveryCity && (
                <p className="text-sm text-red-500 mt-1">
                  {form.formState.errors.deliveryCity.message}
                </p>
              )}
            </div>
            <div>
              <Label htmlFor="deliveryZip">ZIP Code</Label>
              <Input
                id="deliveryZip"
                placeholder="12345"
                {...form.register("deliveryZip")}
                className="mt-1"
              />
              {form.formState.errors.deliveryZip && (
                <p className="text-sm text-red-500 mt-1">
                  {form.formState.errors.deliveryZip.message}
                </p>
              )}
            </div>
          </div>
          
          <div>
            <Label htmlFor="phone">Phone Number</Label>
            <Input
              id="phone"
              placeholder="For delivery updates"
              {...form.register("phone")}
              className="mt-1"
            />
            {form.formState.errors.phone && (
              <p className="text-sm text-red-500 mt-1">
                {form.formState.errors.phone.message}
              </p>
            )}
          </div>
          
          <div>
            <Label htmlFor="deliveryInstructions">Delivery Instructions (Optional)</Label>
            <Textarea
              id="deliveryInstructions"
              placeholder="Special instructions for delivery"
              rows={2}
              {...form.register("deliveryInstructions")}
              className="mt-1"
            />
          </div>
        </div>
      </div>
      
      <div>
        <h3 className="text-lg font-medium mb-4">Payment Method</h3>
        
        <RadioGroup 
          defaultValue="creditCard"
          {...form.register("paymentMethod")}
          className="space-y-2"
        >
          <div className="flex items-center p-3 border border-neutral-300 rounded-lg">
            <RadioGroupItem id="creditCard" value="creditCard" className="mr-2" />
            <Label htmlFor="creditCard" className="flex items-center cursor-pointer">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5">
                <rect width="20" height="14" x="2" y="5" rx="2" />
                <line x1="2" x2="22" y1="10" y2="10" />
              </svg>
              Credit Card
            </Label>
          </div>
          
          <div className="flex items-center p-3 border border-neutral-300 rounded-lg">
            <RadioGroupItem id="paypal" value="paypal" className="mr-2" />
            <Label htmlFor="paypal" className="flex items-center cursor-pointer">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5">
                <path d="M7 11a4 4 0 0 0 4 4h1a4 4 0 0 0 0-8h-1" />
                <path d="M17 7a4 4 0 0 0-4 4h-1a4 4 0 0 0 0 8h1" />
              </svg>
              PayPal
            </Label>
          </div>
          
          <div className="flex items-center p-3 border border-neutral-300 rounded-lg">
            <RadioGroupItem id="cash" value="cash" className="mr-2" />
            <Label htmlFor="cash" className="flex items-center cursor-pointer">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2 h-5 w-5">
                <circle cx="12" cy="12" r="8" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12" y2="16" />
              </svg>
              Cash on Delivery
            </Label>
          </div>
        </RadioGroup>
        
        {form.formState.errors.paymentMethod && (
          <p className="text-sm text-red-500 mt-1">
            {form.formState.errors.paymentMethod.message}
          </p>
        )}
      </div>
      
      <div className="flex justify-end space-x-3 pt-4">
        <Button 
          type="button" 
          variant="outline"
          onClick={() => setLocation("/")}
        >
          Cancel
        </Button>
        <Button 
          type="submit" 
          className="bg-primary hover:bg-red-600 text-white"
          disabled={isSubmitting}
        >
          {isSubmitting ? "Processing..." : "Place Order"}
        </Button>
      </div>
    </form>
  );
}
