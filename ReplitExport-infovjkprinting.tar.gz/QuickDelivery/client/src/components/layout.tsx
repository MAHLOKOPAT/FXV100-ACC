import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { ShoppingBag, Menu, X } from "lucide-react";
import { useCart } from "@/lib/cart";

type LayoutProps = {
  children: React.ReactNode;
};

export default function Layout({ children }: LayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const cart = useCart();
  const [location] = useLocation();
  const [isMobileCartVisible, setIsMobileCartVisible] = useState(false);

  // Close mobile menu when location changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  // Handle mobile cart visibility
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileCartVisible(false);
      } else {
        setIsMobileCartVisible(cart.getTotalItems() > 0);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [cart.getTotalItems()]);

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold font-accent">
              <span className="mr-1 text-primary">Hungry</span>
              <span className="text-secondary">Desire</span>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            <Link href="/" className="text-neutral-700 hover:text-primary">
              Home
            </Link>
            <Link href="/" className="text-neutral-700 hover:text-primary">
              Restaurants
            </Link>
            <Link href="/orders" className="text-neutral-700 hover:text-primary">
              Orders
            </Link>
            <Link href="/noise-cancellation" className="text-neutral-700 hover:text-primary">
              Noise Cancellation
            </Link>
          </div>
          
          <div className="flex items-center">
            <Link href="/checkout" className="relative p-2 text-neutral-800 hover:text-primary">
              <ShoppingBag className="w-5 h-5" />
              {cart.getTotalItems() > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cart.getTotalItems()}
                </span>
              )}
            </Link>
            <button className="md:hidden ml-2 text-neutral-800" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
        
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="container mx-auto px-4 py-2">
              <div className="flex flex-col space-y-3 py-2">
                <Link href="/" className="text-neutral-700 hover:text-primary">
                  Home
                </Link>
                <Link href="/" className="text-neutral-700 hover:text-primary">
                  Restaurants
                </Link>
                <Link href="/orders" className="text-neutral-700 hover:text-primary">
                  Orders
                </Link>
                <Link href="/noise-cancellation" className="text-neutral-700 hover:text-primary">
                  Noise Cancellation
                </Link>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Main content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Mobile cart button */}
      {isMobileCartVisible && (
        <div className="fixed bottom-4 right-4 lg:hidden z-50">
          <Link href="/checkout" className="bg-primary text-white rounded-full p-4 shadow-lg flex items-center">
            <ShoppingBag className="w-5 h-5 mr-2" />
            <span>View Cart</span>
            <span className="ml-2 bg-white text-primary rounded-full h-6 w-6 flex items-center justify-center text-sm font-bold">
              {cart.getTotalItems()}
            </span>
          </Link>
        </div>
      )}
    </div>
  );
}
