import { useEffect, useRef } from "react";

interface NoiseCancellationVisualizerProps {
  isActive: boolean;
  level: number;
}

export default function NoiseCancellationVisualizer({
  isActive,
  level
}: NoiseCancellationVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationFrameRef = useRef<number>();
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas size
    const setCanvasSize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    
    setCanvasSize();
    window.addEventListener('resize', setCanvasSize);
    
    // Noise particles
    const particles: {
      x: number;
      y: number;
      size: number;
      speed: number;
      opacity: number;
      hue: number;
    }[] = [];
    
    // Create initial particles
    const createParticles = () => {
      particles.length = 0;
      const particleCount = 50;
      
      for (let i = 0; i < particleCount; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          size: Math.random() * 4 + 1,
          speed: Math.random() * 3 + 1,
          opacity: Math.random() * 0.5 + 0.2,
          hue: Math.random() * 30 + 200, // Blue-ish colors
        });
      }
    };
    
    createParticles();
    
    // Draw function
    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      if (!isActive) {
        // Just draw a static "sound waves" visualization when not active
        ctx.beginPath();
        ctx.arc(canvas.width / 2, canvas.height / 2, 50, 0, Math.PI * 2);
        ctx.strokeStyle = '#e0e0e0';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        ctx.beginPath();
        ctx.arc(canvas.width / 2, canvas.height / 2, 80, 0, Math.PI * 2);
        ctx.strokeStyle = '#e0e0e0';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        
        ctx.beginPath();
        ctx.arc(canvas.width / 2, canvas.height / 2, 110, 0, Math.PI * 2);
        ctx.strokeStyle = '#e0e0e0';
        ctx.lineWidth = 1;
        ctx.stroke();
        
        // Draw microphone icon
        ctx.fillStyle = '#888';
        ctx.font = '24px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🎤', canvas.width / 2, canvas.height / 2);
        
        return;
      }
      
      // Active visualization
      
      // Draw noise particles
      particles.forEach((p) => {
        // Filter effect based on noise cancellation level
        const filterFactor = level / 100;
        if (Math.random() > filterFactor) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fillStyle = `hsla(${p.hue}, 80%, 50%, ${p.opacity})`;
          ctx.fill();
        }
        
        // Move particles
        p.y -= p.speed;
        p.opacity -= 0.002;
        
        // Reset particles that go off screen
        if (p.y < -10 || p.opacity <= 0) {
          p.y = canvas.height + 10;
          p.x = Math.random() * canvas.width;
          p.opacity = Math.random() * 0.5 + 0.2;
        }
      });
      
      // Draw sound wave circles
      const time = Date.now() * 0.001;
      const basePulse = Math.sin(time * 2) * 10;
      const pulseFactor = 1 - level / 150; // Reduce pulse effect with higher noise cancellation
      
      for (let i = 0; i < 3; i++) {
        const radius = (i + 1) * 40 + basePulse * pulseFactor;
        const alpha = 0.8 - i * 0.2;
        
        ctx.beginPath();
        ctx.arc(canvas.width / 2, canvas.height / 2, radius, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(25, 118, 210, ${alpha})`;
        ctx.lineWidth = 2 - i * 0.5;
        ctx.stroke();
      }
      
      // Draw filter zone
      ctx.beginPath();
      ctx.arc(canvas.width / 2, canvas.height / 2, 140, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(76, 175, 80, ${level / 100})`;
      ctx.lineWidth = 3;
      ctx.stroke();
      
      // Draw center icon
      ctx.fillStyle = '#1976d2';
      ctx.beginPath();
      ctx.arc(canvas.width / 2, canvas.height / 2, 20, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = 'white';
      ctx.font = '18px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🎤', canvas.width / 2, canvas.height / 2);
      
      animationFrameRef.current = requestAnimationFrame(draw);
    };
    
    draw();
    
    // Clean up
    return () => {
      window.removeEventListener('resize', setCanvasSize);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isActive, level]);
  
  return (
    <canvas 
      ref={canvasRef} 
      className="w-full h-full rounded-lg bg-slate-50"
    />
  );
}