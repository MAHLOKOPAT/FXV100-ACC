import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import Layout from "@/components/layout";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Clock, Bike, Star } from "lucide-react";
import MenuItemCard from "@/components/menu-item";
import OrderSummary from "@/components/order-summary";

export default function RestaurantPage() {
  const [, params] = useRoute("/restaurant/:id");
  const restaurantId = params ? parseInt(params.id) : 0;
  const [selectedCategory, setSelectedCategory] = useState("Popular Items");

  // Get restaurant details
  const { data: restaurant, isLoading: restaurantLoading } = useQuery({
    queryKey: [`/api/restaurants/${restaurantId}`],
  });

  // Get menu items
  const { data: menuItems, isLoading: menuLoading } = useQuery({
    queryKey: [`/api/restaurants/${restaurantId}/menu`],
  });

  // Get unique menu categories
  const menuCategories = ["Popular Items"];
  if (menuItems) {
    const categorySet = new Set<string>();
    
    menuItems.forEach((item: any) => {
      categorySet.add(item.category);
    });
    
    menuCategories.push(...Array.from(categorySet));
  }

  // Filter menu items by category
  const filteredMenuItems = selectedCategory === "Popular Items"
    ? menuItems?.filter((item: any) => item.isPopular)
    : menuItems?.filter((item: any) => item.category === selectedCategory);

  if (restaurantLoading || !restaurant) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-gray-200 rounded w-1/4"></div>
            <div className="h-64 bg-gray-200 rounded-xl"></div>
            <div className="h-10 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-full"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-3/4">
            <div className="flex items-center mb-6">
              <Link href="/">
                <a className="flex items-center text-neutral-700 hover:text-primary mr-4">
                  <ArrowLeft className="w-5 h-5 mr-1" /> Back to restaurants
                </a>
              </Link>
              <h2 className="text-2xl font-bold">{restaurant.name}</h2>
            </div>

            <div className="bg-white rounded-xl overflow-hidden shadow-md mb-8">
              <img 
                src={restaurant.image} 
                alt={`${restaurant.name} restaurant banner`} 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <div className="flex flex-wrap items-center mb-4">
                  <div className="flex items-center mr-6 mb-2">
                    <span className="flex items-center text-[#FFC043] mr-2 font-medium">
                      <Star className="w-4 h-4 mr-1 fill-current" />
                      {restaurant.rating.toFixed(1)}
                    </span>
                    <span className="text-neutral-600">({restaurant.reviewCount}+ ratings)</span>
                  </div>
                  <div className="flex items-center mr-6 mb-2">
                    <Clock className="w-4 h-4 mr-1 text-neutral-600" />
                    <span className="text-neutral-600">{restaurant.deliveryTime}</span>
                  </div>
                  <div className="flex items-center mb-2">
                    <Bike className="w-4 h-4 mr-1 text-neutral-600" />
                    <span className="text-neutral-600">{restaurant.deliveryFee}</span>
                  </div>
                </div>
                <p className="text-neutral-700">{restaurant.description}</p>
              </div>
            </div>

            <div className="mb-8">
              <div className="flex overflow-x-auto scrollbar-hide space-x-4 mb-6">
                {menuCategories.map((category) => (
                  <Button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`whitespace-nowrap px-4 py-2 rounded-full ${
                      selectedCategory === category
                        ? "bg-primary text-white"
                        : "bg-neutral-100 text-neutral-700 hover:bg-neutral-200"
                    }`}
                    variant="ghost"
                  >
                    {category}
                  </Button>
                ))}
              </div>

              <h3 className="text-xl font-bold mb-4">{selectedCategory}</h3>
              
              {menuLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="bg-white rounded-xl overflow-hidden shadow-sm flex animate-pulse">
                      <div className="p-4 flex-1">
                        <div className="h-5 bg-gray-200 rounded w-3/4 mb-2"></div>
                        <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                        <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                      </div>
                      <div className="min-w-[120px] bg-gray-200"></div>
                    </div>
                  ))}
                </div>
              ) : filteredMenuItems?.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {filteredMenuItems.map((item: any) => (
                    <MenuItemCard 
                      key={item.id} 
                      item={item} 
                      restaurantId={restaurant.id}
                      restaurantName={restaurant.name}
                    />
                  ))}
                </div>
              ) : (
                <div className="bg-neutral-50 border border-neutral-200 text-neutral-700 px-4 py-6 rounded-lg text-center">
                  <p className="mb-2">No items found in this category.</p>
                  <p className="text-sm">Try selecting a different category from above.</p>
                </div>
              )}
            </div>
          </div>

          <div className="lg:w-1/4 hidden lg:block">
            <OrderSummary />
          </div>
        </div>
      </div>
    </Layout>
  );
}
