import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Layout from "@/components/layout";
import CategoryFilter from "@/components/ui/category-filter";
import RestaurantCard from "@/components/restaurant-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { SearchIcon } from "lucide-react";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState("All Restaurants");
  const [address, setAddress] = useState("");

  // Get all restaurants
  const { data: restaurants, isLoading, error } = useQuery({
    queryKey: ["/api/restaurants"],
  });

  // Filter restaurants by category
  const filteredRestaurants = selectedCategory === "All Restaurants"
    ? restaurants
    : restaurants?.filter((restaurant: any) => 
        restaurant.categories.includes(selectedCategory)
      );

  // Get unique categories from all restaurants
  const allCategories = ["All Restaurants"];
  if (restaurants) {
    const categorySet = new Set<string>();
    
    restaurants.forEach((restaurant: any) => {
      restaurant.categories.forEach((category: string) => {
        categorySet.add(category);
      });
    });
    
    allCategories.push(...Array.from(categorySet));
  }

  return (
    <Layout>
      {/* Hero Banner */}
      <section className="bg-gradient-to-r from-primary to-secondary text-white py-10 md:py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              Delicious food delivered to your door
            </h1>
            <p className="text-lg md:text-xl opacity-90 mb-8">
              Order from your favorite restaurants and track your delivery in real-time
            </p>
            <div className="relative max-w-xl mx-auto">
              <Input
                type="text"
                placeholder="Enter your delivery address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-5 py-6 rounded-lg text-neutral-800 focus:outline-none focus:ring-2 focus:ring-accent"
              />
              <Button 
                className="absolute right-2 top-2 bg-[#FFC043] hover:bg-amber-500 text-white px-4 py-2 rounded-lg font-medium transition"
              >
                Find Food
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Category Navigation */}
      <CategoryFilter
        categories={allCategories}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
      />

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-full">
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-6">
                {selectedCategory === "All Restaurants" 
                  ? "Popular Restaurants" 
                  : selectedCategory + " Restaurants"}
              </h2>
              
              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[...Array(6)].map((_, i) => (
                    <div key={i} className="bg-white rounded-xl overflow-hidden shadow-md p-4 h-72 animate-pulse">
                      <div className="w-full h-40 bg-gray-200 rounded-lg mb-4"></div>
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  ))}
                </div>
              ) : error ? (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                  <p>Error loading restaurants. Please try again later.</p>
                </div>
              ) : filteredRestaurants?.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredRestaurants.map((restaurant: any) => (
                    <RestaurantCard key={restaurant.id} restaurant={restaurant} />
                  ))}
                </div>
              ) : (
                <div className="bg-neutral-50 border border-neutral-200 text-neutral-700 px-4 py-8 rounded-lg text-center">
                  <SearchIcon className="mx-auto h-12 w-12 text-neutral-400 mb-2" />
                  <h3 className="text-lg font-medium mb-1">No restaurants found</h3>
                  <p>No restaurants found in the selected category. Try another category.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </Layout>
  );
}
