import { useCart } from "@/lib/cart";
import Layout from "@/components/layout";
import CheckoutForm from "@/components/checkout-form";
import { ShoppingBag, ArrowLeft } from "lucide-react";
import { Link, useLocation } from "wouter";
import CartItem from "@/components/cart-item";
import { Button } from "@/components/ui/button";

export default function CheckoutPage() {
  const cart = useCart();
  const [, setLocation] = useLocation();

  // Redirect to home if cart is empty
  if (cart.getTotalItems() === 0) {
    return (
      <Layout>
        <div className="container mx-auto px-4 py-12">
          <div className="max-w-lg mx-auto bg-white rounded-xl shadow-md p-8 text-center">
            <div className="text-6xl text-neutral-300 mb-4">
              <ShoppingBag className="mx-auto" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Your Cart is Empty</h2>
            <p className="text-neutral-600 mb-6">
              Add items from a restaurant to start your order
            </p>
            <Button 
              onClick={() => setLocation("/")}
              className="bg-primary hover:bg-red-600 text-white px-6 py-2"
            >
              Browse Restaurants
            </Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6">
          <Link href="/" className="flex items-center text-neutral-700 hover:text-primary">
            <ArrowLeft className="w-5 h-5 mr-1" /> Continue Shopping
          </Link>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          <div className="lg:w-3/5">
            <div className="bg-white rounded-xl shadow-md p-6 mb-6">
              <h2 className="text-2xl font-bold mb-6">Checkout</h2>
              <CheckoutForm />
            </div>
          </div>

          <div className="lg:w-2/5">
            <div className="bg-white rounded-xl shadow-md p-6 sticky top-28">
              <h2 className="text-xl font-bold mb-4">Order Summary</h2>
              
              <div className="text-sm font-medium text-neutral-700 mb-3">
                Order from: <span className="text-primary">{cart.restaurant?.name}</span>
              </div>
              
              <div className="space-y-4 mb-6 max-h-64 overflow-y-auto scrollbar-hide">
                {cart.items.map((item) => (
                  <CartItem key={item.menuItemId} item={item} />
                ))}
              </div>
              
              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between text-neutral-700">
                  <span>Subtotal</span>
                  <span>${cart.getSubtotal().toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-neutral-700">
                  <span>Delivery Fee</span>
                  <span>Free</span>
                </div>
                <div className="flex justify-between text-neutral-700">
                  <span>Tax</span>
                  <span>${cart.getTax().toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg mt-3">
                  <span>Total</span>
                  <span>${cart.getTotal().toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
