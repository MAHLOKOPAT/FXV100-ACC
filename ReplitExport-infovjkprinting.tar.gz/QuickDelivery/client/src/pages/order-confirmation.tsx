import { useRoute } from "wouter";
import Layout from "@/components/layout";
import OrderTracking from "@/components/order-tracking";

export default function OrderConfirmationPage() {
  const [, params] = useRoute("/order-confirmation/:id");
  const orderId = params ? parseInt(params.id) : 0;

  return (
    <Layout>
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto bg-white rounded-xl shadow-md p-6">
          <OrderTracking orderId={orderId} />
        </div>
      </div>
    </Layout>
  );
}
