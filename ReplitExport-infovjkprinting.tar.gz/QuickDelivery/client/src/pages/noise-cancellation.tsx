import Layout from "@/components/layout";
import CallInterface from "@/components/call-interface";
import { AudioProvider } from "@/lib/audio-context";

export default function NoiseCancellationPage() {
  return (
    <Layout>
      <div className="container max-w-6xl mx-auto py-8">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold">Noise Cancellation for Calls</h1>
          <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">
            Enhance your call quality by automatically removing background noise. 
            Perfect for working in noisy environments or taking calls on the go.
          </p>
        </div>
        
        <AudioProvider>
          <CallInterface />
        </AudioProvider>
        
        <div className="mt-16">
          <h2 className="text-2xl font-semibold mb-4">How it works</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm border">
              <div className="mb-4 text-primary text-2xl">1</div>
              <h3 className="text-xl font-medium mb-2">Noise Detection</h3>
              <p className="text-muted-foreground">
                Our advanced algorithm automatically detects background noise in your audio input, 
                distinguishing it from your voice.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border">
              <div className="mb-4 text-primary text-2xl">2</div>
              <h3 className="text-xl font-medium mb-2">Noise Filtering</h3>
              <p className="text-muted-foreground">
                The detected noise is filtered out in real-time, leaving only your voice 
                crisp and clear for your callers.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm border">
              <div className="mb-4 text-primary text-2xl">3</div>
              <h3 className="text-xl font-medium mb-2">Customizable Settings</h3>
              <p className="text-muted-foreground">
                Adjust the noise cancellation level, echo cancellation, and auto gain control
                to perfectly match your environment.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mt-16 bg-slate-50 p-8 rounded-lg">
          <h2 className="text-2xl font-semibold mb-4">Perfect for:</h2>
          <ul className="grid sm:grid-cols-2 gap-4">
            <li className="flex items-start">
              <span className="text-primary mr-2">✓</span>
              <span>Working from coffee shops or co-working spaces</span>
            </li>
            <li className="flex items-start">
              <span className="text-primary mr-2">✓</span>
              <span>Taking calls while on public transportation</span>
            </li>
            <li className="flex items-start">
              <span className="text-primary mr-2">✓</span>
              <span>Attending meetings with background family noise</span>
            </li>
            <li className="flex items-start">
              <span className="text-primary mr-2">✓</span>
              <span>Remote team communication in noisy environments</span>
            </li>
            <li className="flex items-start">
              <span className="text-primary mr-2">✓</span>
              <span>Recording clear audio for podcasts or videos</span>
            </li>
            <li className="flex items-start">
              <span className="text-primary mr-2">✓</span>
              <span>Professional client meetings from any location</span>
            </li>
          </ul>
        </div>
      </div>
    </Layout>
  );
}