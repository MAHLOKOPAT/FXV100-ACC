import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { AudioPreset } from "@shared/schema";
import { apiRequest } from "./queryClient";

interface AudioContextType {
  // Audio stream state
  stream: MediaStream | null;
  isStreamActive: boolean;
  
  // Audio settings state
  userId: string;
  noiseCancellationLevel: number;
  echoCancellation: boolean;
  autoGainControl: boolean;
  presets: AudioPreset[];
  
  // Functions
  startStream: () => Promise<void>;
  stopStream: () => void;
  saveSettings: () => Promise<void>;
  updateNoiseCancellationLevel: (level: number) => void;
  toggleEchoCancellation: () => void;
  toggleAutoGainControl: () => void;
  addPreset: (name: string) => Promise<void>;
  deletePreset: (name: string) => Promise<void>;
  applyPreset: (preset: AudioPreset) => void;
}

const AudioContext = createContext<AudioContextType | null>(null);

// Generate a consistent user ID based on browser fingerprint or random ID stored in localStorage
const getUserId = (): string => {
  const storedId = localStorage.getItem('audio_user_id');
  if (storedId) return storedId;
  
  const newId = Math.random().toString(36).substring(2, 15);
  localStorage.setItem('audio_user_id', newId);
  return newId;
};

export function AudioProvider({ children }: { children: ReactNode }) {
  // Audio stream state
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isStreamActive, setIsStreamActive] = useState(false);
  
  // User identity and settings
  const [userId] = useState<string>(getUserId());
  const [noiseCancellationLevel, setNoiseCancellationLevel] = useState<number>(50);
  const [echoCancellation, setEchoCancellation] = useState<boolean>(true);
  const [autoGainControl, setAutoGainControl] = useState<boolean>(true);
  const [presets, setPresets] = useState<AudioPreset[]>([]);
  
  // Fetch user settings on initial load
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await apiRequest('GET', `/api/audio-settings/${userId}`);
        const data = await response.json();
        
        if (data) {
          if (typeof data.noiseCancellationLevel === 'number') {
            setNoiseCancellationLevel(data.noiseCancellationLevel);
          }
          if (typeof data.echoCancellation === 'boolean') {
            setEchoCancellation(data.echoCancellation);
          }
          if (typeof data.autoGainControl === 'boolean') {
            setAutoGainControl(data.autoGainControl);
          }
          if (Array.isArray(data.presets)) {
            setPresets(data.presets);
          }
        }
      } catch (error) {
        // User has no settings yet, will create on first save
        console.log("No existing audio settings found");
      }
    };
    
    fetchSettings();
  }, [userId]);
  
  // Start audio stream with applied settings
  const startStream = async () => {
    try {
      if (stream) {
        stopStream();
      }
      
      // Request audio with noise cancellation settings
      const audioStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation,
          noiseSuppression: noiseCancellationLevel > 0,
          autoGainControl
        },
        video: false
      });
      
      setStream(audioStream);
      setIsStreamActive(true);
      
      // Apply Web Audio API processing for noise cancellation level
      if (noiseCancellationLevel > 0) {
        // In a real implementation, we would apply different levels of noise
        // reduction using Web Audio API nodes here
        console.log(`Applied noise cancellation level: ${noiseCancellationLevel}%`);
      }
      
    } catch (error) {
      console.error("Error accessing microphone:", error);
      alert("Could not access your microphone. Please check permissions and try again.");
    }
  };
  
  // Stop the audio stream
  const stopStream = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
      setIsStreamActive(false);
    }
  };
  
  // Save current settings to the server
  const saveSettings = async () => {
    try {
      await apiRequest('POST', '/api/audio-settings', {
        userId,
        noiseCancellationLevel,
        echoCancellation,
        autoGainControl,
        presets
      });
      console.log("Audio settings saved successfully");
    } catch (error) {
      console.error("Error saving audio settings:", error);
    }
  };
  
  // Update the noise cancellation level
  const updateNoiseCancellationLevel = (level: number) => {
    setNoiseCancellationLevel(level);
    
    // If stream is active, we would apply the new level in real-time
    if (stream) {
      console.log(`Updated noise cancellation level: ${level}%`);
      // Real implementation would update the web audio processing here
    }
  };
  
  // Toggle echo cancellation
  const toggleEchoCancellation = () => {
    setEchoCancellation(!echoCancellation);
    
    // If stream is active, restart it to apply new settings
    if (stream) {
      stopStream();
      startStream();
    }
  };
  
  // Toggle auto gain control
  const toggleAutoGainControl = () => {
    setAutoGainControl(!autoGainControl);
    
    // If stream is active, restart it to apply new settings
    if (stream) {
      stopStream();
      startStream();
    }
  };
  
  // Add a new preset with current settings
  const addPreset = async (name: string) => {
    const newPreset: AudioPreset = {
      name,
      noiseCancellationLevel,
      echoCancellation,
      autoGainControl
    };
    
    try {
      const response = await apiRequest(
        'POST',
        `/api/audio-settings/${userId}/presets`, 
        newPreset
      );
      
      const data = await response.json();
      if (data && Array.isArray(data.presets)) {
        setPresets(data.presets);
      }
    } catch (error) {
      console.error("Error adding preset:", error);
    }
  };
  
  // Delete a preset by name
  const deletePreset = async (name: string) => {
    try {
      const response = await apiRequest(
        'DELETE',
        `/api/audio-settings/${userId}/presets/${name}`
      );
      
      const data = await response.json();
      if (data && Array.isArray(data.presets)) {
        setPresets(data.presets);
      }
    } catch (error) {
      console.error("Error deleting preset:", error);
    }
  };
  
  // Apply a preset's settings
  const applyPreset = (preset: AudioPreset) => {
    setNoiseCancellationLevel(preset.noiseCancellationLevel);
    setEchoCancellation(preset.echoCancellation);
    setAutoGainControl(preset.autoGainControl);
    
    // If stream is active, restart it to apply new settings
    if (stream) {
      stopStream();
      startStream();
    }
  };
  
  // Clean up stream on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [stream]);
  
  return (
    <AudioContext.Provider value={{
      stream,
      isStreamActive,
      userId,
      noiseCancellationLevel,
      echoCancellation,
      autoGainControl,
      presets,
      startStream,
      stopStream,
      saveSettings,
      updateNoiseCancellationLevel,
      toggleEchoCancellation,
      toggleAutoGainControl,
      addPreset,
      deletePreset,
      applyPreset
    }}>
      {children}
    </AudioContext.Provider>
  );
}

export function useAudio() {
  const context = useContext(AudioContext);
  if (!context) {
    throw new Error("useAudio must be used within an AudioProvider");
  }
  return context;
}