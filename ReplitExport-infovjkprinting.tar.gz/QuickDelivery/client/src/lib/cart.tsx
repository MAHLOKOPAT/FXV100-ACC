import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { CartItem } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface CartContextType {
  items: CartItem[];
  restaurant: { id: number; name: string } | null;
  addItem: (item: CartItem, restaurantId: number, restaurantName: string) => void;
  removeItem: (menuItemId: number) => void;
  updateQuantity: (menuItemId: number, quantity: number) => void;
  clearCart: () => void;
  getTotalItems: () => number;
  getSubtotal: () => number;
  getTax: () => number;
  getTotal: () => number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [restaurant, setRestaurant] = useState<{ id: number; name: string } | null>(null);
  const { toast } = useToast();
  const taxRate = 0.08; // 8% tax

  // Load cart from localStorage on initial load
  useEffect(() => {
    try {
      const savedCart = localStorage.getItem('foodDashCart');
      const savedRestaurant = localStorage.getItem('foodDashRestaurant');
      
      if (savedCart) {
        setItems(JSON.parse(savedCart));
      }
      
      if (savedRestaurant) {
        setRestaurant(JSON.parse(savedRestaurant));
      }
    } catch (error) {
      console.error('Failed to load cart from localStorage', error);
    }
  }, []);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('foodDashCart', JSON.stringify(items));
      
      if (restaurant) {
        localStorage.setItem('foodDashRestaurant', JSON.stringify(restaurant));
      }
    } catch (error) {
      console.error('Failed to save cart to localStorage', error);
    }
  }, [items, restaurant]);

  const addItem = (item: CartItem, restaurantId: number, restaurantName: string) => {
    // Check if adding from a different restaurant
    if (restaurant && restaurant.id !== restaurantId && items.length > 0) {
      toast({
        title: "Different Restaurant",
        description: `Your cart contains items from ${restaurant.name}. Do you want to clear your cart and add this item?`,
        action: (
          <button 
            className="bg-primary text-white px-3 py-1 rounded-md"
            onClick={() => {
              setItems([item]);
              setRestaurant({ id: restaurantId, name: restaurantName });
              toast({
                title: "Cart Updated",
                description: `${item.name} added to your cart.`
              });
            }}
          >
            Clear & Add
          </button>
        ),
      });
      return;
    }

    // Set restaurant if not already set
    if (!restaurant) {
      setRestaurant({ id: restaurantId, name: restaurantName });
    }

    // Check if item already exists in cart
    const existingItemIndex = items.findIndex(i => i.menuItemId === item.menuItemId);
    
    if (existingItemIndex !== -1) {
      // Update existing item quantity
      const updatedItems = [...items];
      updatedItems[existingItemIndex].quantity += item.quantity;
      setItems(updatedItems);
    } else {
      // Add new item
      setItems([...items, item]);
    }

    toast({
      title: "Added to Cart",
      description: `${item.name} added to your cart.`
    });
  };

  const removeItem = (menuItemId: number) => {
    setItems(items.filter(item => item.menuItemId !== menuItemId));
    
    toast({
      title: "Item Removed",
      description: "Item removed from your cart."
    });

    // If cart is empty, reset restaurant
    if (items.length === 1) {
      setRestaurant(null);
      localStorage.removeItem('foodDashRestaurant');
    }
  };

  const updateQuantity = (menuItemId: number, quantity: number) => {
    if (quantity <= 0) {
      removeItem(menuItemId);
      return;
    }

    setItems(items.map(item => 
      item.menuItemId === menuItemId ? { ...item, quantity } : item
    ));
  };

  const clearCart = () => {
    setItems([]);
    setRestaurant(null);
    localStorage.removeItem('foodDashCart');
    localStorage.removeItem('foodDashRestaurant');
    
    toast({
      title: "Cart Cleared",
      description: "Your cart has been cleared."
    });
  };

  const getTotalItems = () => {
    return items.reduce((total, item) => total + item.quantity, 0);
  };

  const getSubtotal = () => {
    return items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };

  const getTax = () => {
    return getSubtotal() * taxRate;
  };

  const getTotal = () => {
    return getSubtotal() + getTax();
  };

  return (
    <CartContext.Provider
      value={{
        items,
        restaurant,
        addItem,
        removeItem,
        updateQuantity,
        clearCart,
        getTotalItems,
        getSubtotal,
        getTax,
        getTotal
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
