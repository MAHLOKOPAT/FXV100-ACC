import { pgTable, text, serial, integer, boolean, doublePrecision, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Audio Settings schema
export const audioSettings = pgTable("audio_settings", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  noiseCancellationLevel: integer("noise_cancellation_level").default(50).notNull(), // 0-100
  echoCancellation: boolean("echo_cancellation").default(true).notNull(),
  autoGainControl: boolean("auto_gain_control").default(true).notNull(),
  presets: jsonb("presets").notNull().$type<{
    name: string;
    noiseCancellationLevel: number;
    echoCancellation: boolean;
    autoGainControl: boolean;
  }[]>().default([]),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertAudioSettingsSchema = createInsertSchema(audioSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Restaurant schema
export const restaurants = pgTable("restaurants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  categories: text("categories").array().notNull(),
  rating: doublePrecision("rating").notNull(),
  reviewCount: integer("review_count").notNull(),
  priceLevel: text("price_level").notNull(),
  deliveryTime: text("delivery_time").notNull(),
  deliveryFee: text("delivery_fee").notNull(),
  address: text("address").notNull(),
  city: text("city").notNull(),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
});

export const insertRestaurantSchema = createInsertSchema(restaurants).omit({
  id: true,
});

// Menu Item schema
export const menuItems = pgTable("menu_items", {
  id: serial("id").primaryKey(),
  restaurantId: integer("restaurant_id").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: doublePrecision("price").notNull(),
  image: text("image").notNull(),
  category: text("category").notNull(),
  isPopular: boolean("is_popular").default(false),
});

export const insertMenuItemSchema = createInsertSchema(menuItems).omit({
  id: true,
});

// Order schema
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  restaurantId: integer("restaurant_id").notNull(),
  status: text("status").notNull(), // 'pending', 'confirmed', 'preparing', 'delivering', 'delivered'
  totalAmount: doublePrecision("total_amount").notNull(),
  deliveryAddress: text("delivery_address").notNull(),
  deliveryCity: text("delivery_city").notNull(),
  deliveryZip: text("delivery_zip").notNull(),
  phone: text("phone").notNull(),
  deliveryInstructions: text("delivery_instructions"),
  paymentMethod: text("payment_method").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertOrderSchema = createInsertSchema(orders).omit({
  id: true,
  createdAt: true,
});

// Order Item schema (items included in an order)
export const orderItems = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id").notNull(),
  menuItemId: integer("menu_item_id").notNull(),
  quantity: integer("quantity").notNull(),
  price: doublePrecision("price").notNull(),
  name: text("name").notNull(),
});

export const insertOrderItemSchema = createInsertSchema(orderItems).omit({
  id: true,
});

// Types for frontend and backend
export type Restaurant = typeof restaurants.$inferSelect;
export type InsertRestaurant = z.infer<typeof insertRestaurantSchema>;

export type MenuItem = typeof menuItems.$inferSelect;
export type InsertMenuItem = z.infer<typeof insertMenuItemSchema>;

export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = z.infer<typeof insertOrderItemSchema>;

// Cart item type (for frontend)
export type CartItem = {
  menuItemId: number;
  name: string;
  price: number;
  quantity: number;
};

// Audio settings types
export type AudioSetting = typeof audioSettings.$inferSelect;
export type InsertAudioSetting = z.infer<typeof insertAudioSettingsSchema>;
export type AudioPreset = {
  name: string;
  noiseCancellationLevel: number;
  echoCancellation: boolean;
  autoGainControl: boolean;
};
