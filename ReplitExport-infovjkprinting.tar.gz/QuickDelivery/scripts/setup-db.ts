import { db } from "../server/db";
import { restaurants, menuItems } from "../shared/schema";
import { MemStorage } from "../server/storage";

// Create a memory storage to access mock data
const memStorage = new MemStorage();

async function setupDatabase() {
  console.log("Setting up database...");
  
  try {
    // First clear any existing data
    console.log("Clearing existing data...");
    await db.delete(menuItems);
    await db.delete(restaurants);
    
    // Get mock data from memory storage
    console.log("Fetching mock data...");
    const mockRestaurants = await memStorage.getAllRestaurants();
    
    // Insert restaurants
    console.log("Inserting restaurant data...");
    for (const restaurant of mockRestaurants) {
      const { id, ...rest } = restaurant;
      await db.insert(restaurants).values(rest).returning();
    }
    
    // Get and insert menu items
    for (const restaurant of mockRestaurants) {
      console.log(`Inserting menu items for restaurant ${restaurant.id}...`);
      const mockMenuItems = await memStorage.getMenuItemsByRestaurantId(restaurant.id);
      
      for (const menuItem of mockMenuItems) {
        const { id, ...rest } = menuItem;
        await db.insert(menuItems).values(rest).returning();
      }
    }
    
    console.log("Database setup complete!");
  } catch (error) {
    console.error("Error setting up database:", error);
  } finally {
    // Close the database connection
    process.exit(0);
  }
}

setupDatabase();