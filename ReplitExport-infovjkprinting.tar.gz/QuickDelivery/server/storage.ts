import { 
  type Restaurant, type InsertRestaurant, 
  type MenuItem, type InsertMenuItem,
  type Order, type InsertOrder,
  type OrderItem, type InsertOrderItem,
  type AudioSetting, type InsertAudioSetting,
  restaurants, menuItems, orders, orderItems, audioSettings
} from "@shared/schema";
import { db } from "./db";
import { eq, sql } from "drizzle-orm";

export interface IStorage {
  // Restaurant methods
  getAllRestaurants(): Promise<Restaurant[]>;
  getRestaurantById(id: number): Promise<Restaurant | undefined>;
  getRestaurantsByCategory(category: string): Promise<Restaurant[]>;
  
  // Menu item methods
  getMenuItemsByRestaurantId(restaurantId: number): Promise<MenuItem[]>;
  getMenuItemById(id: number): Promise<MenuItem | undefined>;
  
  // Order methods
  createOrder(order: InsertOrder): Promise<Order>;
  getOrderById(id: number): Promise<Order | undefined>;
  updateOrderStatus(id: number, status: string): Promise<Order | undefined>;
  
  // Order item methods
  addOrderItems(orderItems: InsertOrderItem[]): Promise<OrderItem[]>;
  getOrderItemsByOrderId(orderId: number): Promise<OrderItem[]>;
  
  // Audio settings methods
  getAudioSettingsByUserId(userId: string): Promise<AudioSetting | undefined>;
  createAudioSettings(audioSetting: InsertAudioSetting): Promise<AudioSetting>;
  updateAudioSettings(id: number, audioSetting: Partial<InsertAudioSetting>): Promise<AudioSetting | undefined>;
  addAudioPreset(userId: string, preset: AudioSetting['presets'][0]): Promise<AudioSetting | undefined>;
  deleteAudioPreset(userId: string, presetName: string): Promise<AudioSetting | undefined>;
}

// Mock data for restaurants
const mockRestaurants: Restaurant[] = [
  {
    id: 1,
    name: "Burger Haven",
    description: "Gourmet burgers, fresh ingredients, and signature sauces. Our flame-grilled patties are made with 100% premium beef.",
    image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    categories: ["Burgers", "Fast Food"],
    rating: 4.7,
    reviewCount: 200,
    priceLevel: "$$",
    deliveryTime: "25-35 min",
    deliveryFee: "Free delivery",
    address: "123 Main Street",
    city: "San Francisco",
    latitude: 37.7749,
    longitude: -122.4194
  },
  {
    id: 2,
    name: "Pizza Palace",
    description: "Authentic Italian pizza with fresh toppings and house-made sauce on a perfectly crispy crust.",
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    categories: ["Pizza", "Italian"],
    rating: 4.5,
    reviewCount: 180,
    priceLevel: "$$",
    deliveryTime: "30-40 min",
    deliveryFee: "Free over $15",
    address: "456 Market Street",
    city: "San Francisco",
    latitude: 37.7899,
    longitude: -122.4001
  },
  {
    id: 3,
    name: "Sushi Spot",
    description: "Premium sushi and Japanese cuisine made with the freshest ingredients and traditional recipes.",
    image: "https://images.unsplash.com/photo-1516714435131-44d6b64dc6a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    categories: ["Sushi", "Japanese", "Asian"],
    rating: 4.8,
    reviewCount: 150,
    priceLevel: "$$$",
    deliveryTime: "35-50 min",
    deliveryFee: "$2.99 delivery",
    address: "789 Mission Street",
    city: "San Francisco",
    latitude: 37.7830,
    longitude: -122.4075
  },
  {
    id: 4,
    name: "Taco Fiesta",
    description: "Authentic Mexican street food with fresh ingredients and bold flavors.",
    image: "https://images.unsplash.com/photo-1457460866886-40ef8d4b42a0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    categories: ["Mexican", "Fast Casual"],
    rating: 4.3,
    reviewCount: 120,
    priceLevel: "$",
    deliveryTime: "20-30 min",
    deliveryFee: "Free delivery",
    address: "222 Valencia Street",
    city: "San Francisco",
    latitude: 37.7694,
    longitude: -122.4221
  },
  {
    id: 5,
    name: "Fresh Greens",
    description: "Healthy salads and grain bowls with locally sourced ingredients and house-made dressings.",
    image: "https://images.unsplash.com/photo-1565958011703-44f9829ba187?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    categories: ["Salads", "Healthy", "Vegan"],
    rating: 4.6,
    reviewCount: 90,
    priceLevel: "$$",
    deliveryTime: "20-35 min",
    deliveryFee: "$1.99 delivery",
    address: "555 Howard Street",
    city: "San Francisco",
    latitude: 37.7875,
    longitude: -122.3965
  },
  {
    id: 6,
    name: "Sweet Treats",
    description: "Delicious desserts, baked goods, and sweet treats for any occasion.",
    image: "https://images.unsplash.com/photo-1544025162-d76694265947?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80",
    categories: ["Bakery", "Desserts"],
    rating: 4.9,
    reviewCount: 110,
    priceLevel: "$$",
    deliveryTime: "30-45 min",
    deliveryFee: "Free over $20",
    address: "888 Folsom Street",
    city: "San Francisco",
    latitude: 37.7810,
    longitude: -122.4020
  }
];

// Mock data for menu items
const mockMenuItems: MenuItem[] = [
  // Burger Haven menu items
  {
    id: 1,
    restaurantId: 1,
    name: "Classic Cheeseburger",
    description: "Beef patty, cheese, lettuce, tomato, pickle, special sauce",
    price: 8.99,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=300&q=80",
    category: "Burgers",
    isPopular: true
  },
  {
    id: 2,
    restaurantId: 1,
    name: "Double Bacon Deluxe",
    description: "Double beef patty, bacon, cheese, caramelized onions",
    price: 12.99,
    image: "https://images.unsplash.com/photo-1553979459-d2229ba7433b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=300&q=80",
    category: "Burgers",
    isPopular: true
  },
  {
    id: 3,
    restaurantId: 1,
    name: "Crispy Chicken Sandwich",
    description: "Crispy chicken, lettuce, mayo, pickles on brioche bun",
    price: 9.99,
    image: "https://images.unsplash.com/photo-1606755962773-d324e0a13086?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=300&q=80",
    category: "Chicken",
    isPopular: true
  },
  {
    id: 4,
    restaurantId: 1,
    name: "Loaded Fries",
    description: "Crispy fries topped with cheese, bacon bits and sour cream",
    price: 6.99,
    image: "https://images.unsplash.com/photo-1585109649139-366815a0d713?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=300&q=80",
    category: "Sides",
    isPopular: true
  },
  {
    id: 5,
    restaurantId: 1,
    name: "Chocolate Milkshake",
    description: "Rich and creamy chocolate shake with whipped cream",
    price: 5.49,
    image: "https://images.unsplash.com/photo-1572490122747-3968b75cc699?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=300&q=80",
    category: "Beverages",
    isPopular: true
  },
  {
    id: 6,
    restaurantId: 1,
    name: "Veggie Burger",
    description: "Plant-based patty with fresh veggies and special sauce",
    price: 10.99,
    image: "https://images.unsplash.com/photo-1585238342024-78d387f4a707?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=300&q=80",
    category: "Vegetarian",
    isPopular: true
  },
  // Pizza Palace menu items
  {
    id: 7,
    restaurantId: 2,
    name: "Margherita Pizza",
    description: "Classic pizza with tomato sauce, mozzarella, and fresh basil",
    price: 14.99,
    image: "https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=300&h=300&q=80",
    category: "Pizza",
    isPopular: true
  },
  // Add menu items for other restaurants similarly
];

export class MemStorage implements IStorage {
  private restaurants: Map<number, Restaurant>;
  private menuItems: Map<number, MenuItem>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem[]>;
  private audioSettings: Map<number, AudioSetting>;
  private audioSettingsByUserId: Map<string, number>;
  private nextOrderId: number;
  private nextOrderItemId: number;
  private nextAudioSettingsId: number;

  constructor() {
    this.restaurants = new Map();
    this.menuItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.audioSettings = new Map();
    this.audioSettingsByUserId = new Map();
    this.nextOrderId = 1;
    this.nextOrderItemId = 1;
    this.nextAudioSettingsId = 1;

    // Initialize with mock data
    mockRestaurants.forEach(restaurant => {
      this.restaurants.set(restaurant.id, restaurant);
    });

    mockMenuItems.forEach(menuItem => {
      this.menuItems.set(menuItem.id, menuItem);
    });
  }

  // Restaurant methods
  async getAllRestaurants(): Promise<Restaurant[]> {
    return Array.from(this.restaurants.values());
  }

  async getRestaurantById(id: number): Promise<Restaurant | undefined> {
    return this.restaurants.get(id);
  }

  async getRestaurantsByCategory(category: string): Promise<Restaurant[]> {
    if (category === "All Restaurants") {
      return this.getAllRestaurants();
    }
    
    return Array.from(this.restaurants.values()).filter(restaurant => 
      restaurant.categories.includes(category)
    );
  }

  // Menu item methods
  async getMenuItemsByRestaurantId(restaurantId: number): Promise<MenuItem[]> {
    return Array.from(this.menuItems.values()).filter(menuItem => 
      menuItem.restaurantId === restaurantId
    );
  }

  async getMenuItemById(id: number): Promise<MenuItem | undefined> {
    return this.menuItems.get(id);
  }

  // Order methods
  async createOrder(order: InsertOrder): Promise<Order> {
    const id = this.nextOrderId++;
    const newOrder: Order = { ...order, id, createdAt: new Date() };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async getOrderById(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, status };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  // Order item methods
  async addOrderItems(items: InsertOrderItem[]): Promise<OrderItem[]> {
    const orderItems: OrderItem[] = [];
    
    for (const item of items) {
      const id = this.nextOrderItemId++;
      const orderItem: OrderItem = { ...item, id };
      orderItems.push(orderItem);
    }
    
    const existingItems = this.orderItems.get(items[0].orderId) || [];
    this.orderItems.set(items[0].orderId, [...existingItems, ...orderItems]);
    
    return orderItems;
  }

  async getOrderItemsByOrderId(orderId: number): Promise<OrderItem[]> {
    return this.orderItems.get(orderId) || [];
  }

  // Audio settings methods
  async getAudioSettingsByUserId(userId: string): Promise<AudioSetting | undefined> {
    const settingId = this.audioSettingsByUserId.get(userId);
    if (!settingId) return undefined;
    return this.audioSettings.get(settingId);
  }

  async createAudioSettings(audioSetting: InsertAudioSetting): Promise<AudioSetting> {
    const id = this.nextAudioSettingsId++;
    const now = new Date();
    const newSetting: AudioSetting = { 
      ...audioSetting, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    
    this.audioSettings.set(id, newSetting);
    this.audioSettingsByUserId.set(audioSetting.userId, id);
    
    return newSetting;
  }

  async updateAudioSettings(id: number, audioSetting: Partial<InsertAudioSetting>): Promise<AudioSetting | undefined> {
    const existingSetting = this.audioSettings.get(id);
    if (!existingSetting) return undefined;
    
    const updatedSetting: AudioSetting = { 
      ...existingSetting, 
      ...audioSetting, 
      updatedAt: new Date() 
    };
    
    this.audioSettings.set(id, updatedSetting);
    
    // Update user mapping if userId changed
    if (audioSetting.userId && audioSetting.userId !== existingSetting.userId) {
      this.audioSettingsByUserId.set(audioSetting.userId, id);
    }
    
    return updatedSetting;
  }

  async addAudioPreset(userId: string, preset: AudioSetting['presets'][0]): Promise<AudioSetting | undefined> {
    const settingId = this.audioSettingsByUserId.get(userId);
    if (!settingId) return undefined;
    
    const setting = this.audioSettings.get(settingId);
    if (!setting) return undefined;
    
    // Check if preset with same name already exists
    const existingPresetIndex = setting.presets.findIndex(p => p.name === preset.name);
    
    if (existingPresetIndex >= 0) {
      // Replace existing preset
      const updatedPresets = [...setting.presets];
      updatedPresets[existingPresetIndex] = preset;
      
      const updatedSetting: AudioSetting = {
        ...setting,
        presets: updatedPresets,
        updatedAt: new Date()
      };
      
      this.audioSettings.set(settingId, updatedSetting);
      return updatedSetting;
    } else {
      // Add new preset
      const updatedSetting: AudioSetting = {
        ...setting,
        presets: [...setting.presets, preset],
        updatedAt: new Date()
      };
      
      this.audioSettings.set(settingId, updatedSetting);
      return updatedSetting;
    }
  }

  async deleteAudioPreset(userId: string, presetName: string): Promise<AudioSetting | undefined> {
    const settingId = this.audioSettingsByUserId.get(userId);
    if (!settingId) return undefined;
    
    const setting = this.audioSettings.get(settingId);
    if (!setting) return undefined;
    
    const updatedPresets = setting.presets.filter(p => p.name !== presetName);
    
    if (updatedPresets.length === setting.presets.length) {
      // Preset not found, no changes needed
      return setting;
    }
    
    const updatedSetting: AudioSetting = {
      ...setting,
      presets: updatedPresets,
      updatedAt: new Date()
    };
    
    this.audioSettings.set(settingId, updatedSetting);
    return updatedSetting;
  }
}

// Database Storage implementation
export class DatabaseStorage implements IStorage {
  // Restaurant methods
  async getAllRestaurants(): Promise<Restaurant[]> {
    return await db.select().from(restaurants);
  }

  async getRestaurantById(id: number): Promise<Restaurant | undefined> {
    const [restaurant] = await db.select().from(restaurants).where(eq(restaurants.id, id));
    return restaurant;
  }

  async getRestaurantsByCategory(category: string): Promise<Restaurant[]> {
    return await db.select().from(restaurants).where(sql`${restaurants.categories} @> ARRAY[${category}]`);
  }

  // Menu item methods
  async getMenuItemsByRestaurantId(restaurantId: number): Promise<MenuItem[]> {
    return await db.select().from(menuItems).where(eq(menuItems.restaurantId, restaurantId));
  }

  async getMenuItemById(id: number): Promise<MenuItem | undefined> {
    const [menuItem] = await db.select().from(menuItems).where(eq(menuItems.id, id));
    return menuItem;
  }

  // Order methods
  async createOrder(order: InsertOrder): Promise<Order> {
    const [newOrder] = await db.insert(orders).values(order).returning();
    return newOrder;
  }

  async getOrderById(id: number): Promise<Order | undefined> {
    const [order] = await db.select().from(orders).where(eq(orders.id, id));
    return order;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order | undefined> {
    const [updatedOrder] = await db
      .update(orders)
      .set({ status })
      .where(eq(orders.id, id))
      .returning();
    return updatedOrder;
  }

  // Order item methods
  async addOrderItems(orderItems: InsertOrderItem[]): Promise<OrderItem[]> {
    return await db.insert(orderItems).values(orderItems).returning();
  }

  async getOrderItemsByOrderId(orderId: number): Promise<OrderItem[]> {
    return await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  }

  // Audio settings methods
  async getAudioSettingsByUserId(userId: string): Promise<AudioSetting | undefined> {
    const [setting] = await db.select().from(audioSettings).where(eq(audioSettings.userId, userId));
    return setting;
  }

  async createAudioSettings(audioSetting: InsertAudioSetting): Promise<AudioSetting> {
    const [newSetting] = await db.insert(audioSettings).values(audioSetting).returning();
    return newSetting;
  }

  async updateAudioSettings(id: number, audioSetting: Partial<InsertAudioSetting>): Promise<AudioSetting | undefined> {
    const [updatedSetting] = await db
      .update(audioSettings)
      .set({ ...audioSetting, updatedAt: new Date() })
      .where(eq(audioSettings.id, id))
      .returning();
    return updatedSetting;
  }

  async addAudioPreset(userId: string, preset: AudioSetting['presets'][0]): Promise<AudioSetting | undefined> {
    // First, get the current settings
    const [setting] = await db
      .select()
      .from(audioSettings)
      .where(eq(audioSettings.userId, userId));
    
    if (!setting) return undefined;
    
    // Check if preset with the same name exists
    const existingPresetIndex = setting.presets.findIndex(p => p.name === preset.name);
    let updatedPresets: AudioSetting['presets'];
    
    if (existingPresetIndex >= 0) {
      // Replace existing preset
      updatedPresets = [...setting.presets];
      updatedPresets[existingPresetIndex] = preset;
    } else {
      // Add new preset
      updatedPresets = [...setting.presets, preset];
    }
    
    // Update the settings with the new presets
    const [updatedSetting] = await db
      .update(audioSettings)
      .set({ 
        presets: updatedPresets,
        updatedAt: new Date()
      })
      .where(eq(audioSettings.id, setting.id))
      .returning();
    
    return updatedSetting;
  }

  async deleteAudioPreset(userId: string, presetName: string): Promise<AudioSetting | undefined> {
    // First, get the current settings
    const [setting] = await db
      .select()
      .from(audioSettings)
      .where(eq(audioSettings.userId, userId));
    
    if (!setting) return undefined;
    
    // Filter out the preset to delete
    const updatedPresets = setting.presets.filter(p => p.name !== presetName);
    
    if (updatedPresets.length === setting.presets.length) {
      // Preset not found, no changes needed
      return setting;
    }
    
    // Update the settings with the filtered presets
    const [updatedSetting] = await db
      .update(audioSettings)
      .set({ 
        presets: updatedPresets,
        updatedAt: new Date()
      })
      .where(eq(audioSettings.id, setting.id))
      .returning();
    
    return updatedSetting;
  }
}

// Use database storage
export const storage = new DatabaseStorage();
