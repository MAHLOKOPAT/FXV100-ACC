import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertOrderSchema, insertOrderItemSchema, insertAudioSettingsSchema, AudioPreset } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Prefix all routes with /api
  const api = "/api";

  // Get all restaurants
  app.get(`${api}/restaurants`, async (req: Request, res: Response) => {
    try {
      const restaurants = await storage.getAllRestaurants();
      res.json(restaurants);
    } catch (error) {
      res.status(500).json({ message: "Error fetching restaurants" });
    }
  });

  // Get restaurant by ID
  app.get(`${api}/restaurants/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid restaurant ID" });
      }

      const restaurant = await storage.getRestaurantById(id);
      if (!restaurant) {
        return res.status(404).json({ message: "Restaurant not found" });
      }

      res.json(restaurant);
    } catch (error) {
      res.status(500).json({ message: "Error fetching restaurant" });
    }
  });

  // Get restaurants by category
  app.get(`${api}/restaurants/category/:category`, async (req: Request, res: Response) => {
    try {
      const category = req.params.category;
      const restaurants = await storage.getRestaurantsByCategory(category);
      res.json(restaurants);
    } catch (error) {
      res.status(500).json({ message: "Error fetching restaurants by category" });
    }
  });

  // Get menu items by restaurant ID
  app.get(`${api}/restaurants/:id/menu`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid restaurant ID" });
      }

      const menuItems = await storage.getMenuItemsByRestaurantId(id);
      res.json(menuItems);
    } catch (error) {
      res.status(500).json({ message: "Error fetching menu items" });
    }
  });

  // Get menu item by ID
  app.get(`${api}/menu-items/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid menu item ID" });
      }

      const menuItem = await storage.getMenuItemById(id);
      if (!menuItem) {
        return res.status(404).json({ message: "Menu item not found" });
      }

      res.json(menuItem);
    } catch (error) {
      res.status(500).json({ message: "Error fetching menu item" });
    }
  });

  // Create order
  app.post(`${api}/orders`, async (req: Request, res: Response) => {
    try {
      const orderData = insertOrderSchema.parse(req.body);
      const order = await storage.createOrder(orderData);
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating order" });
    }
  });

  // Add order items
  app.post(`${api}/orders/:id/items`, async (req: Request, res: Response) => {
    try {
      const orderId = parseInt(req.params.id);
      if (isNaN(orderId)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }

      const order = await storage.getOrderById(orderId);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      const itemsData = z.array(insertOrderItemSchema).parse(req.body);
      const orderItems = await storage.addOrderItems(itemsData);
      res.status(201).json(orderItems);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order item data", errors: error.errors });
      }
      res.status(500).json({ message: "Error adding order items" });
    }
  });

  // Get order by ID with items
  app.get(`${api}/orders/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }

      const order = await storage.getOrderById(id);
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }

      const orderItems = await storage.getOrderItemsByOrderId(id);
      const restaurant = await storage.getRestaurantById(order.restaurantId);
      
      res.json({
        ...order,
        items: orderItems,
        restaurant
      });
    } catch (error) {
      res.status(500).json({ message: "Error fetching order" });
    }
  });

  // Update order status
  app.patch(`${api}/orders/:id/status`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid order ID" });
      }

      const statusSchema = z.object({ status: z.string() });
      const { status } = statusSchema.parse(req.body);

      const updatedOrder = await storage.updateOrderStatus(id, status);
      if (!updatedOrder) {
        return res.status(404).json({ message: "Order not found" });
      }

      res.json(updatedOrder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid status data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating order status" });
    }
  });

  // ------------ Audio Settings Routes -----------

  // Get audio settings by user ID
  app.get(`${api}/audio-settings/:userId`, async (req: Request, res: Response) => {
    try {
      const userId = req.params.userId;
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      const settings = await storage.getAudioSettingsByUserId(userId);
      if (!settings) {
        return res.status(404).json({ message: "Audio settings not found" });
      }

      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Error fetching audio settings" });
    }
  });

  // Create or update audio settings
  app.post(`${api}/audio-settings`, async (req: Request, res: Response) => {
    try {
      const settingsData = insertAudioSettingsSchema.parse(req.body);
      
      // Check if settings already exist for this user
      const existingSettings = await storage.getAudioSettingsByUserId(settingsData.userId);
      
      let settings;
      if (existingSettings) {
        // Update existing settings
        settings = await storage.updateAudioSettings(existingSettings.id, settingsData);
      } else {
        // Create new settings
        settings = await storage.createAudioSettings(settingsData);
      }
      
      res.status(201).json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid audio settings data", errors: error.errors });
      }
      res.status(500).json({ message: "Error saving audio settings" });
    }
  });

  // Update audio settings
  app.patch(`${api}/audio-settings/:id`, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid settings ID" });
      }

      const updateSchema = z.object({
        noiseCancellationLevel: z.number().min(0).max(100).optional(),
        echoCancellation: z.boolean().optional(),
        autoGainControl: z.boolean().optional()
      });

      const settingsData = updateSchema.parse(req.body);
      const updatedSettings = await storage.updateAudioSettings(id, settingsData);
      
      if (!updatedSettings) {
        return res.status(404).json({ message: "Audio settings not found" });
      }

      res.json(updatedSettings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid audio settings data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating audio settings" });
    }
  });

  // Add audio preset
  app.post(`${api}/audio-settings/:userId/presets`, async (req: Request, res: Response) => {
    try {
      const userId = req.params.userId;
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      const presetSchema = z.object({
        name: z.string().min(1),
        noiseCancellationLevel: z.number().min(0).max(100),
        echoCancellation: z.boolean(),
        autoGainControl: z.boolean()
      });

      const preset = presetSchema.parse(req.body);
      const updatedSettings = await storage.addAudioPreset(userId, preset);
      
      if (!updatedSettings) {
        return res.status(404).json({ message: "Audio settings not found" });
      }

      res.json(updatedSettings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid preset data", errors: error.errors });
      }
      res.status(500).json({ message: "Error adding audio preset" });
    }
  });

  // Delete audio preset
  app.delete(`${api}/audio-settings/:userId/presets/:presetName`, async (req: Request, res: Response) => {
    try {
      const { userId, presetName } = req.params;
      if (!userId || !presetName) {
        return res.status(400).json({ message: "User ID and preset name are required" });
      }

      const updatedSettings = await storage.deleteAudioPreset(userId, presetName);
      
      if (!updatedSettings) {
        return res.status(404).json({ message: "Audio settings not found" });
      }

      res.json(updatedSettings);
    } catch (error) {
      res.status(500).json({ message: "Error deleting audio preset" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
