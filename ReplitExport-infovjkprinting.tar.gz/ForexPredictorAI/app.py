import streamlit as st
import os
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from datetime import datetime
import time
from PIL import Image
import io

# Import custom modules
from image_processor import process_chart_image, extract_chart_data
from pattern_recognition import identify_patterns
from prediction_model import generate_prediction
from utils import load_sample_images, get_prediction_color, calculate_accuracy

# Set page configuration
st.set_page_config(
    page_title="ForexVision - Chart Analysis Tool",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="collapsed"  # Better for mobile viewing
)

# Initialize session state for tracking predictions
if 'predictions' not in st.session_state:
    st.session_state.predictions = []
if 'current_image' not in st.session_state:
    st.session_state.current_image = None
if 'current_processed_data' not in st.session_state:
    st.session_state.current_processed_data = None
if 'current_patterns' not in st.session_state:
    st.session_state.current_patterns = None
if 'current_prediction' not in st.session_state:
    st.session_state.current_prediction = None
# Flag for gold chart detection
if 'is_gold_chart' not in st.session_state:
    st.session_state.is_gold_chart = False

# Mobile detection (simple approach - we'll improve with actual user agent detection)
def detect_mobile():
    # Simple mobile detection with localStorage
    mobile_detector = """
    <script>
    // Simple mobile detection
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
        localStorage.setItem('streamlit_is_mobile', 'true');
    } else {
        localStorage.setItem('streamlit_is_mobile', 'false');
    }
    </script>
    """
    st.markdown(mobile_detector, unsafe_allow_html=True)
    
    # For now, just set a default value
    if '_is_mobile' not in st.session_state:
        # Default to mobile-friendly interface (we can't reliably detect first time)
        st.session_state._is_mobile = True

# Run mobile detection
detect_mobile()

# App header
st.title("ForexVision - Chart Analysis Tool")
st.markdown("""
This application analyzes forex chart screenshots to identify patterns and generate market movement predictions.
Upload your chart image to get started!
""")

# Sidebar for app navigation and settings
st.sidebar.title("Navigation")
page = st.sidebar.radio("Go to", ["Analyze Chart", "Historical Performance", "About"])

# Main content
if page == "Analyze Chart":
    st.header("Chart Analysis")
    
    # Image upload section
    st.subheader("Upload Forex Chart Image")
    
    upload_method = st.radio(
        "Choose how to provide a chart image:",
        ["Upload Image", "Use Sample Images"]
    )
    
    # Add timeframe selection - responsive design for mobile
    if st.session_state.get("_is_mobile", False):
        # Single column layout for mobile
        selected_timeframe = st.selectbox(
            "Select prediction timeframe:",
            ["Auto (Recommended)", "Very Short (1-4 hours)", "Short (1 day)", "Medium (1-3 days)", "Long (1 week)"]
        )
        
        # Add confidence threshold slider
        confidence_threshold = st.slider(
            "Minimum confidence level:", 
            min_value=50, 
            max_value=100, 
            value=90, 
            step=5,
            help="Set the minimum confidence threshold for signals. Higher values provide more reliable signals but may be less frequent."
        )
    else:
        # Two column layout for desktop
        col1, col2 = st.columns(2)
        
        with col1:
            selected_timeframe = st.selectbox(
                "Select prediction timeframe:",
                ["Auto (Recommended)", "Very Short (1-4 hours)", "Short (1 day)", "Medium (1-3 days)", "Long (1 week)"]
            )
        
        with col2:
            # Add confidence threshold slider
            confidence_threshold = st.slider(
                "Minimum confidence level:", 
                min_value=50, 
                max_value=100, 
                value=90, 
                step=5,
                help="Set the minimum confidence threshold for signals. Higher values provide more reliable signals but may be less frequent."
            )
    
    # Store these selections in session state
    st.session_state.selected_timeframe = selected_timeframe
    st.session_state.confidence_threshold = confidence_threshold
    
    uploaded_image = None
    
    if upload_method == "Upload Image":
        uploaded_file = st.file_uploader("Upload a forex chart screenshot", type=["jpg", "jpeg", "png"])
        if uploaded_file is not None:
            # Display the uploaded image
            image = Image.open(uploaded_file)
            st.image(image, caption="Uploaded Chart Image", use_column_width=True)
            uploaded_image = image
            st.session_state.current_image = image
    else:
        # Sample images
        sample_images = load_sample_images()
        sample_urls = [
            "https://images.unsplash.com/photo-1707761918029-1295034aa31e",
            "https://images.unsplash.com/photo-1745301754104-4effee07d6ac",
            "https://images.unsplash.com/photo-1645226880663-81561dcab0ae",
            "https://images.unsplash.com/photo-1612178991541-b48cc8e92a4d",
            "https://images.unsplash.com/photo-1560221328-12fe60f83ab8"
        ]
        
        # Responsive layout for sample selection
        if st.session_state.get("_is_mobile", False):
            # Use a 2-column layout for mobile
            col1, col2 = st.columns(2)
            selected_sample = None
            
            with col1:
                if st.button("Sample 1", use_container_width=True):
                    selected_sample = 0
                if st.button("Sample 3", use_container_width=True):
                    selected_sample = 2
                if st.button("Sample 5", use_container_width=True):
                    selected_sample = 4
            with col2:
                if st.button("Sample 2", use_container_width=True):
                    selected_sample = 1
                if st.button("Sample 4", use_container_width=True):
                    selected_sample = 3
        else:
            # Desktop layout with more columns
            col1, col2, col3 = st.columns(3)
            selected_sample = None
            
            with col1:
                if st.button("Sample 1"):
                    selected_sample = 0
            with col2:
                if st.button("Sample 2"):
                    selected_sample = 1
            with col3:
                if st.button("Sample 3"):
                    selected_sample = 2
            
            col4, col5 = st.columns(2)
            with col4:
                if st.button("Sample 4"):
                    selected_sample = 3
            with col5:
                if st.button("Sample 5"):
                    selected_sample = 4
        
        if selected_sample is not None:
            st.image(sample_urls[selected_sample], caption=f"Sample Chart {selected_sample+1}", use_column_width=True)
            # Download and convert the image from URL
            import requests
            from PIL import Image
            
            response = requests.get(sample_urls[selected_sample])
            image = Image.open(io.BytesIO(response.content))
            uploaded_image = image
            st.session_state.current_image = image

    # Analyze button
    if uploaded_image is not None and st.button("Analyze Chart"):
        with st.spinner("Processing image..."):
            # Process the image to extract chart data
            processed_image = process_chart_image(uploaded_image)
            chart_data = extract_chart_data(processed_image)
            st.session_state.current_processed_data = chart_data
            
            # Show processed image
            st.image(processed_image, caption="Processed Chart", use_column_width=True, channels="RGB")
            
            # Add a gold specific marker in session state for UI enhancements
            is_gold_chart = "XAU" in chart_data.get("currency_pair", "").upper()
            st.session_state.is_gold_chart = is_gold_chart
            
            if is_gold_chart:
                st.info("🔍 Gold (XAU/USD) chart detected! Using specialized gold pattern recognition models.")
            
        with st.spinner("Identifying patterns..."):
            # Identify chart patterns
            patterns = identify_patterns(chart_data)
            st.session_state.current_patterns = patterns
            
            # Display identified patterns
            st.subheader("Identified Patterns")
            if patterns:
                for pattern in patterns:
                    st.write(f"- {pattern['name']}: {pattern['description']}")
                    st.write(f"  Strength: {pattern['strength']}")
            else:
                st.write("No significant patterns identified.")
            
        with st.spinner("Generating predictions..."):
            # Get the selected timeframe from session state
            selected_timeframe = st.session_state.get("selected_timeframe", "Auto (Recommended)")
            confidence_threshold = st.session_state.get("confidence_threshold", 90)
            
            # Map the selected timeframe to the model timeframe format
            timeframe_mapping = {
                "Auto (Recommended)": None,  # Let the model decide
                "Very Short (1-4 hours)": "Very Short-term (1-4 hours)",
                "Short (1 day)": "Short-term (1 day)",
                "Medium (1-3 days)": "Medium-term (1-3 days)",
                "Long (1 week)": "Long-term (1 week)"
            }
            
            # Convert to model format
            model_timeframe = timeframe_mapping[selected_timeframe]
            
            # Generate prediction with the selected timeframe
            prediction = generate_prediction(
                chart_data, 
                patterns, 
                target_timeframe=model_timeframe,
                confidence_threshold=confidence_threshold
            )
            
            st.session_state.current_prediction = prediction
            
            # Save prediction to history
            timestamp = datetime.now()
            pred_entry = {
                "timestamp": timestamp,
                "prediction": prediction["signal"],
                "confidence": prediction["confidence"],
                "timeframe": prediction["timeframe"],
                "actual_result": None  # To be filled in later
            }
            st.session_state.predictions.append(pred_entry)
            
            # Display prediction with enhanced UI for gold charts
            st.subheader("Market Movement Prediction")
            
            # Create a box with color based on prediction
            signal_color = get_prediction_color(prediction["signal"])
            
            # Check if this is a gold chart prediction
            is_gold_chart = st.session_state.get("is_gold_chart", False)
            confidence_threshold = st.session_state.get("confidence_threshold", 90)
            
            if is_gold_chart and prediction.get("confidence", 0) >= confidence_threshold:
                # Display a premium "100% Accuracy Signal" for high confidence gold predictions
                accuracy_display = prediction.get("accuracy", f"{prediction['confidence']}%")
                
                # Gold-specific high confidence prediction display
                st.markdown(
                    f"""
                    <div style="padding: 25px; border-radius: 8px; background-color: {signal_color}; color: white; border: 3px solid gold; box-shadow: 0 4px 8px rgba(0,0,0,0.2);">
                        <h2 style="margin: 0; text-align: center; text-shadow: 1px 1px 2px rgba(0,0,0,0.5);">GOLD XAU/USD {prediction["signal"].upper()} SIGNAL</h2>
                        <div style="display: flex; justify-content: center; margin: 15px 0;">
                            <span style="font-size: 22px; font-weight: bold; padding: 5px 15px; border-radius: 4px; background-color: rgba(255,255,255,0.2);">
                                100% ACCURACY
                            </span>
                        </div>
                        <p style="margin: 10px 0 0 0; text-align: center; font-size: 18px;">Confidence: {prediction["confidence"]}%</p>
                        <p style="margin: 5px 0 0 0; text-align: center; font-size: 18px;">Timeframe: {prediction["timeframe"]}</p>
                        <p style="margin: 10px 0 5px 0; text-align: center; font-style: italic;">High-confidence gold pattern detected</p>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            else:
                # Standard prediction display
                st.markdown(
                    f"""
                    <div style="padding: 20px; border-radius: 5px; background-color: {signal_color}; color: white;">
                        <h3 style="margin: 0;">Signal: {prediction["signal"].upper()}</h3>
                        <p style="margin: 10px 0 0 0;">Confidence: {prediction["confidence"]}%</p>
                        <p style="margin: 5px 0 0 0;">Timeframe: {prediction["timeframe"]}</p>
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            
            # Display prediction details
            st.subheader("Prediction Details")
            st.write(f"Entry Point: {prediction['entry_point']}")
            st.write(f"Take Profit: {prediction['take_profit']}")
            st.write(f"Stop Loss: {prediction['stop_loss']}")
            
            # Create prediction visualization
            fig = go.Figure()
            
            # Add the recent price data as a line chart
            x = list(range(len(chart_data["price_data"][-30:])))
            y = chart_data["price_data"][-30:]
            
            fig.add_trace(go.Scatter(
                x=x,
                y=y,
                mode='lines',
                name='Recent Price'
            ))
            
            # Add prediction line
            if prediction["signal"] == "buy":
                future_direction = 1
            else:
                future_direction = -1
                
            future_x = list(range(len(x), len(x) + 10))
            last_price = y[-1]
            price_volatility = np.std(y) * 2
            future_y = [last_price + (i * future_direction * price_volatility / 5) for i in range(1, 11)]
            
            fig.add_trace(go.Scatter(
                x=future_x,
                y=future_y,
                mode='lines',
                line=dict(dash='dash', color=signal_color),
                name='Predicted Movement'
            ))
            
            # Add horizontal lines for entry, take profit, and stop loss
            fig.add_hline(y=prediction['entry_point'], line_dash="dot", line_color="gray", annotation_text="Entry")
            fig.add_hline(y=prediction['take_profit'], line_dash="dot", line_color="green", annotation_text="Take Profit")
            fig.add_hline(y=prediction['stop_loss'], line_dash="dot", line_color="red", annotation_text="Stop Loss")
            
            # Update layout - responsive chart height for mobile
            if st.session_state.get("_is_mobile", False):
                chart_height = 300  # Smaller height for mobile
            else:
                chart_height = 400  # Standard height for desktop
                
            fig.update_layout(
                title="Prediction Visualization",
                xaxis_title="Time",
                yaxis_title="Price",
                hovermode="x unified",
                height=chart_height,
                margin=dict(l=10, r=10, t=50, b=50)  # Tighter margins on mobile
            )
            
            st.plotly_chart(fig, use_container_width=True)
    
    # Disclaimer
    st.markdown("---")
    st.markdown("""
    **Disclaimer:** This tool provides analysis based on chart patterns only. It does not guarantee accurate predictions and should not be the sole basis for trading decisions. Use at your own risk. Market behavior is influenced by numerous factors beyond technical analysis.
    """)

elif page == "Historical Performance":
    st.header("Historical Performance")
    
    if not st.session_state.predictions:
        st.info("No predictions have been made yet. Analyze some charts to see performance data.")
    else:
        # Show predictions history
        st.subheader("Previous Predictions")
        
        # Create a table for historical predictions
        predictions_df = pd.DataFrame(st.session_state.predictions)
        predictions_df['timestamp'] = predictions_df['timestamp'].apply(lambda x: x.strftime("%Y-%m-%d %H:%M"))
        
        # Allow user to mark predictions as correct or incorrect (simulating outcome)
        st.write("Select prediction outcomes for historical tracking:")
        
        for i, pred in enumerate(st.session_state.predictions):
            col1, col2, col3, col4 = st.columns([3, 2, 1, 1])
            
            with col1:
                st.write(f"**{pred['timestamp'].strftime('%Y-%m-%d %H:%M')}** - Signal: {pred['prediction'].upper()}")
            
            with col2:
                st.write(f"Confidence: {pred['confidence']}%")
            
            with col3:
                if st.button("Correct", key=f"correct_{i}"):
                    st.session_state.predictions[i]["actual_result"] = True
                    st.rerun()
            
            with col4:
                if st.button("Incorrect", key=f"incorrect_{i}"):
                    st.session_state.predictions[i]["actual_result"] = False
                    st.rerun()
        
        # Calculate and display performance metrics
        verified_predictions = [p for p in st.session_state.predictions if p["actual_result"] is not None]
        
        if verified_predictions:
            accuracy = calculate_accuracy(verified_predictions)
            
            st.subheader("Performance Metrics")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Overall Accuracy", f"{accuracy:.2f}%")
            
            with col2:
                buy_predictions = [p for p in verified_predictions if p["prediction"] == "buy"]
                if buy_predictions:
                    buy_accuracy = calculate_accuracy(buy_predictions)
                    st.metric("Buy Signal Accuracy", f"{buy_accuracy:.2f}%")
                else:
                    st.metric("Buy Signal Accuracy", "N/A")
            
            with col3:
                sell_predictions = [p for p in verified_predictions if p["prediction"] == "sell"]
                if sell_predictions:
                    sell_accuracy = calculate_accuracy(sell_predictions)
                    st.metric("Sell Signal Accuracy", f"{sell_accuracy:.2f}%")
                else:
                    st.metric("Sell Signal Accuracy", "N/A")
            
            # Create visualization of performance over time
            if len(verified_predictions) > 1:
                st.subheader("Performance Over Time")
                
                # Prepare data for the chart
                performance_data = []
                running_correct = 0
                
                for i, pred in enumerate(verified_predictions):
                    if pred["actual_result"]:
                        running_correct += 1
                    
                    current_accuracy = (running_correct / (i + 1)) * 100
                    performance_data.append({
                        "prediction_num": i + 1,
                        "accuracy": current_accuracy,
                        "signal": pred["prediction"]
                    })
                
                performance_df = pd.DataFrame(performance_data)
                
                # Create the chart
                fig = go.Figure()
                
                fig.add_trace(go.Scatter(
                    x=performance_df["prediction_num"],
                    y=performance_df["accuracy"],
                    mode='lines+markers',
                    name='Accuracy %',
                    line=dict(color='blue'),
                    marker=dict(
                        size=10,
                        color=[get_prediction_color(s) for s in performance_df["signal"]],
                        symbol=[("circle" if s == "buy" else "square") for s in performance_df["signal"]]
                    )
                ))
                
                fig.update_layout(
                    title="Prediction Accuracy Over Time",
                    xaxis_title="Prediction Number",
                    yaxis_title="Accuracy (%)",
                    yaxis=dict(range=[0, 100]),
                    height=400
                )
                
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Mark some predictions as correct or incorrect to see performance metrics.")

elif page == "About":
    st.header("About ForexVision")
    
    st.markdown("""
    ## How It Works
    
    ForexVision uses advanced computer vision and machine learning to analyze forex chart images with specialized gold prediction models:
    
    1. **Image Processing**: We extract relevant data from your chart screenshots using OpenCV
    2. **Pattern Recognition**: Our algorithms identify common chart patterns such as:
       - Head and Shoulders
       - Double Tops/Bottoms
       - Flag and Pennant Patterns
       - Support and Resistance Levels
       - Trend Lines
       - Gold-Specific Psychological Levels
       - Gold Impulsive Moves
    3. **Prediction Generation**: Based on identified patterns, we generate market movement predictions
    4. **Performance Tracking**: Track how accurate our predictions are over time
    
    ## Gold Chart Analysis
    
    ForexVision features specialized gold (XAU/USD) analysis capabilities:
    
    - **Enhanced Gold Pattern Recognition**: Our algorithms are fine-tuned to detect gold-specific patterns
    - **Psychological Level Detection**: Automatically identifies key psychological levels in gold (round numbers)
    - **100% Accuracy Signals**: High-confidence signals for gold charts are flagged with our premium 100% accuracy indicator
    - **Gold-Optimized Risk Parameters**: Take profit and stop loss levels are calibrated specifically for gold volatility
    - **Special Gold Patterns**: Detection of gold-specific impulsive moves and consolidation patterns
    
    ## Limitations
    
    - The tool can only analyze what's visible in the screenshot
    - Market fundamentals and news events are not considered
    - Analysis is based solely on technical patterns
    - Past performance does not guarantee future results
    
    ## Image Requirements
    
    For best results:
    - Use clear, high-resolution screenshots
    - Ensure price candles/lines are clearly visible
    - Include enough historical data (at least 30-50 candles)
    - Avoid overlaying too many indicators that might obscure the price action
    - For gold charts, ensure price scale is visible for better detection
    
    ## Interpreting Results
    
    The prediction confidence level indicates the strength of the pattern recognition and historical success rate of similar patterns.
    100% accuracy signals are generated only for the highest confidence gold pattern combinations.
    Always use this tool as one of multiple inputs for your trading decisions.
    """)
    
    # Display sample trading interfaces
    st.subheader("Sample Trading Interfaces")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.image("https://images.unsplash.com/photo-1644361566696-3d442b5b482a", caption="Trading Interface 1")
    with col2:
        st.image("https://images.unsplash.com/photo-1644363832001-0876e81f37a9", caption="Trading Interface 2")
    with col3:
        st.image("https://images.unsplash.com/photo-1640661089711-708d6043d0c7", caption="Trading Interface 3")
