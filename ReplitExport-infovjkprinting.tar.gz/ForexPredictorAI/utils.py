import os
import requests
from PIL import Image
import io
import numpy as np
import random

def load_sample_images():
    """
    Load sample forex chart images for demonstration.
    
    Returns:
        List of PIL Image objects
    """
    sample_urls = [
        "https://images.unsplash.com/photo-1707761918029-1295034aa31e",
        "https://images.unsplash.com/photo-1745301754104-4effee07d6ac",
        "https://images.unsplash.com/photo-1645226880663-81561dcab0ae",
        "https://images.unsplash.com/photo-1612178991541-b48cc8e92a4d",
        "https://images.unsplash.com/photo-1560221328-12fe60f83ab8"
    ]
    
    sample_images = []
    
    for url in sample_urls:
        try:
            response = requests.get(url)
            image = Image.open(io.BytesIO(response.content))
            sample_images.append(image)
        except Exception as e:
            print(f"Error loading sample image: {e}")
    
    return sample_images

def get_prediction_color(signal):
    """
    Get color for prediction display based on signal type.
    
    Args:
        signal: String with prediction signal (buy, sell, neutral)
        
    Returns:
        Color code as string
    """
    if signal == "buy":
        return "#28a745"  # Green
    elif signal == "sell":
        return "#dc3545"  # Red
    else:
        return "#6c757d"  # Gray

def calculate_accuracy(predictions):
    """
    Calculate accuracy percentage from prediction history.
    
    Args:
        predictions: List of prediction dictionaries with actual_result field
        
    Returns:
        Accuracy as a percentage
    """
    if not predictions:
        return 0.0
    
    correct_predictions = sum(1 for p in predictions if p["actual_result"])
    return (correct_predictions / len(predictions)) * 100

def format_currency_value(value, currency_pair="EUR/USD"):
    """
    Format a price value according to forex conventions.
    
    Args:
        value: Numerical price value
        currency_pair: String with the currency pair
        
    Returns:
        Formatted price string
    """
    # Most forex pairs are displayed with 5 decimal places
    return f"{value:.5f}"

def generate_random_seed():
    """
    Generate a random seed based on current time for reproducible randomness.
    
    Returns:
        Integer random seed
    """
    import time
    return int(time.time() * 1000) % 10000
