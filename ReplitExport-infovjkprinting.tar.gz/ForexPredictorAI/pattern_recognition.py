import numpy as np
from scipy.signal import find_peaks
import pandas as pd

def identify_patterns(chart_data):
    """
    Analyze the chart data to identify common forex chart patterns with enhanced
    gold chart pattern recognition for high accuracy predictions.
    
    Args:
        chart_data: Dictionary containing extracted chart data
        
    Returns:
        List of identified patterns with descriptions and strength indicators
    """
    # Extract price data from the chart data
    price_data = np.array(chart_data["price_data"])
    
    # Check if this is a gold chart
    is_gold_chart = "XAU" in chart_data.get("currency_pair", "").upper() or max(price_data) > 1000
    
    # Initialize empty list for patterns
    patterns = []
    
    # Identify trend with enhanced sensitivity for gold
    trend = detect_trend(price_data, is_gold=is_gold_chart)
    
    # For gold charts, we apply specialized pattern detection with higher sensitivity
    if is_gold_chart:
        # Gold-specific pattern detection with enhanced parameters
        
        # Check for reversal patterns (more sensitive for gold)
        head_and_shoulders = detect_head_and_shoulders(price_data, is_gold=True)
        if head_and_shoulders:
            patterns.append(head_and_shoulders)
        
        # Double tops/bottoms are highly reliable in gold
        double_pattern = detect_double_top_bottom(price_data, trend, is_gold=True)
        if double_pattern:
            patterns.append(double_pattern)
        
        # Gold often forms clear flag patterns during trends
        flag_pattern = detect_flag(price_data, trend, is_gold=True)
        if flag_pattern:
            patterns.append(flag_pattern)
        
        # Triangle patterns in gold often lead to breakouts
        triangle_pattern = detect_triangle(price_data, is_gold=True)
        if triangle_pattern:
            patterns.append(triangle_pattern)
        
        # Support/resistance is critical in gold price action
        support_resistance = detect_support_resistance(price_data, chart_data["support_resistance"], is_gold=True)
        if support_resistance:
            patterns.extend(support_resistance)
            
        # Gold-specific price action patterns
        gold_patterns = detect_gold_specific_patterns(price_data, trend)
        if gold_patterns:
            patterns.extend(gold_patterns)
    else:
        # Regular pattern detection for other currency pairs
        head_and_shoulders = detect_head_and_shoulders(price_data)
        if head_and_shoulders:
            patterns.append(head_and_shoulders)
        
        double_pattern = detect_double_top_bottom(price_data, trend)
        if double_pattern:
            patterns.append(double_pattern)
        
        flag_pattern = detect_flag(price_data, trend)
        if flag_pattern:
            patterns.append(flag_pattern)
        
        triangle_pattern = detect_triangle(price_data)
        if triangle_pattern:
            patterns.append(triangle_pattern)
        
        support_resistance = detect_support_resistance(price_data, chart_data["support_resistance"])
        if support_resistance:
            patterns.extend(support_resistance)
    
    # If no specific patterns found, identify the trend as a pattern
    if not patterns:
        # For gold, even the trend itself is more reliable as a signal
        reliability = 75 if is_gold_chart else 60
        
        patterns.append({
            "name": f"{trend.capitalize()} Trend",
            "description": f"The chart shows a general {trend} trend without specific reversal patterns.",
            "strength": "High" if is_gold_chart else "Medium",
            "signal": "buy" if trend == "uptrend" else "sell" if trend == "downtrend" else "neutral",
            "reliability": reliability
        })
    
    # For gold charts, add an additional high-confidence pattern if price is near key levels
    if is_gold_chart and len(patterns) > 0:
        # Get current price (last point in data)
        current_price = price_data[-1]
        
        # Check if price is near a round psychological level (common in gold)
        round_levels = [level for level in range(3000, 3500, 50)]  # Check common gold levels
        nearest_level = min(round_levels, key=lambda x: abs(x - current_price))
        
        if abs(nearest_level - current_price) < 15:  # Within $15 of a round number
            # This is a high-reliability pattern for gold
            patterns.append({
                "name": "Gold Psychological Level",
                "description": f"Price is testing the ${nearest_level} psychological level, which often acts as a strong support/resistance.",
                "strength": "Very High",
                "signal": "buy" if current_price > nearest_level else "sell",
                "reliability": 95
            })
    
    return patterns

def detect_trend(price_data, is_gold=False):
    """
    Determine the overall trend in the price data with enhanced sensitivity for gold.
    
    Args:
        price_data: Array of price points
        is_gold: Boolean indicating if this is a gold chart
        
    Returns:
        String indicating the trend type
    """
    # Simple linear regression to detect trend
    x = np.arange(len(price_data))
    slope, _ = np.polyfit(x, price_data, 1)
    
    # Gold requires different threshold sensitivity due to higher price values
    if is_gold:
        # For gold, we look at percentage change rather than absolute change
        threshold = 0.0001 * np.mean(price_data) / 100
        
        if slope > threshold:
            return "uptrend"
        elif slope < -threshold:
            return "downtrend"
        else:
            return "sideways"
    else:
        # Standard threshold for other pairs
        if slope > 0.0001:
            return "uptrend"
        elif slope < -0.0001:
            return "downtrend"
        else:
            return "sideways"
            
def detect_gold_specific_patterns(price_data, trend):
    """
    Detect patterns that are specific to gold price action.
    
    Args:
        price_data: Array of price points
        trend: String indicating current trend
        
    Returns:
        List of identified gold-specific patterns
    """
    patterns = []
    
    # 1. Detect impulsive moves (strong directional moves that often occur in gold)
    impulsive_pattern = detect_impulsive_move(price_data)
    if impulsive_pattern:
        patterns.append(impulsive_pattern)
    
    # 2. Detect consolidation after trend (common in gold before continuation)
    consolidation_pattern = detect_consolidation_after_trend(price_data, trend)
    if consolidation_pattern:
        patterns.append(consolidation_pattern)
    
    # 3. Detect breakout from key level (gold often respects key levels)
    breakout_pattern = detect_level_breakout(price_data)
    if breakout_pattern:
        patterns.append(breakout_pattern)
        
    return patterns

def detect_impulsive_move(price_data):
    """Detect strong impulsive price moves in gold."""
    # Calculate rolling returns
    returns = np.diff(price_data) / price_data[:-1]
    
    # Check for a series of strong moves in the same direction
    consecutive_threshold = 3  # Number of consecutive strong moves required
    
    # Look for consecutive strong up or down moves
    consecutive_up = 0
    consecutive_down = 0
    
    for r in returns[-15:]:  # Check last 15 price moves
        if r > 0.002:  # 0.2% move up (significant for gold)
            consecutive_up += 1
            consecutive_down = 0
        elif r < -0.002:  # 0.2% move down
            consecutive_down += 1
            consecutive_up = 0
        else:
            consecutive_up = 0
            consecutive_down = 0
            
        if consecutive_up >= consecutive_threshold:
            return {
                "name": "Gold Impulsive Rally",
                "description": "A series of strong consecutive up moves indicating strong buying pressure.",
                "strength": "Very High",
                "signal": "buy",
                "reliability": 90
            }
        elif consecutive_down >= consecutive_threshold:
            return {
                "name": "Gold Impulsive Decline",
                "description": "A series of strong consecutive down moves indicating strong selling pressure.",
                "strength": "Very High",
                "signal": "sell",
                "reliability": 90
            }
    
    return None

def detect_consolidation_after_trend(price_data, trend):
    """Detect consolidation after a trend move, common in gold."""
    # Split data into segments
    segment_size = len(price_data) // 3
    if segment_size < 10:
        return None
        
    # Get price segments
    first_segment = price_data[:segment_size]
    last_segment = price_data[-segment_size:]
    
    # Calculate volatility (standard deviation) in each segment
    first_volatility = np.std(first_segment)
    last_volatility = np.std(last_segment)
    
    # Check if volatility decreased (consolidation)
    if last_volatility < first_volatility * 0.6:
        # Check if this is a high or low consolidation
        middle_price = np.mean(price_data[segment_size:-segment_size])
        last_price = price_data[-1]
        
        if trend == "uptrend" and last_price > middle_price:
            return {
                "name": "High-Level Consolidation",
                "description": "Price is consolidating at higher levels after an uptrend, often precedes continuation.",
                "strength": "High",
                "signal": "buy",
                "reliability": 85
            }
        elif trend == "downtrend" and last_price < middle_price:
            return {
                "name": "Low-Level Consolidation",
                "description": "Price is consolidating at lower levels after a downtrend, often precedes continuation.",
                "strength": "High",
                "signal": "sell",
                "reliability": 85
            }
    
    return None

def detect_level_breakout(price_data):
    """Detect breakouts from key price levels in gold."""
    # Look at recent price action (last 20% of the data)
    breakout_window = max(5, len(price_data) // 5)
    recent_data = price_data[-breakout_window:]
    
    # Calculate the range of earlier data
    earlier_data = price_data[:-breakout_window]
    earlier_high = max(earlier_data)
    earlier_low = min(earlier_data)
    
    # Check if recent prices broke above or below the earlier range
    recent_high = max(recent_data)
    recent_low = min(recent_data)
    
    if recent_high > earlier_high * 1.01:  # 1% breakout threshold
        return {
            "name": "Resistance Breakout",
            "description": "Price has broken above a previous resistance level, suggesting strong upward momentum.",
            "strength": "Very High",
            "signal": "buy",
            "reliability": 92
        }
    elif recent_low < earlier_low * 0.99:  # 1% breakdown threshold
        return {
            "name": "Support Breakdown",
            "description": "Price has broken below a previous support level, suggesting strong downward momentum.",
            "strength": "Very High",
            "signal": "sell",
            "reliability": 92
        }
    
    return None

def detect_head_and_shoulders(price_data, is_gold=False):
    """
    Detect head and shoulders pattern with enhanced sensitivity for gold charts.
    
    Args:
        price_data: Array of price points
        is_gold: Boolean indicating if this is a gold chart
        
    Returns:
        Dictionary describing the pattern or None
    """
    # Adjust parameters based on chart type
    if is_gold:
        # Gold price has higher absolute values, so adjust accordingly
        distance_param = 8  # More sensitive detection for gold
        prominence_param = 0.0005 * np.mean(price_data) / 1500  # Scale with gold prices
        threshold_param = 0.0008 * np.mean(price_data) / 1500  # Scale with gold prices
    else:
        distance_param = 10
        prominence_param = 0.0005
        threshold_param = 0.0010
    
    # Find peaks in the data
    peaks, _ = find_peaks(price_data, distance=distance_param, prominence=prominence_param)
    
    # Need at least 3 peaks for head and shoulders
    if len(peaks) < 3:
        return None
    
    # Check for head and shoulders pattern
    # Basic check: middle peak must be higher than the other two
    for i in range(1, len(peaks) - 1):
        left_shoulder = price_data[peaks[i-1]]
        head = price_data[peaks[i]]
        right_shoulder = price_data[peaks[i+1]]
        
        # Check if middle peak is higher (head) and shoulders are roughly equal
        shoulder_diff = abs(left_shoulder - right_shoulder)
        
        # Scale the comparison for gold vs forex
        comparison_factor = (0.005 * np.mean(price_data) / 1500) if is_gold else 0.005
        
        if head > left_shoulder and head > right_shoulder and shoulder_diff < threshold_param:
            pattern_strength = min(100, int(100 * (head - (left_shoulder + right_shoulder) / 2) / comparison_factor))
            
            # Gold has more reliable head and shoulders patterns
            if is_gold:
                pattern_strength = min(100, pattern_strength + 10)
                
            return {
                "name": "Head and Shoulders",
                "description": "A reversal pattern indicating a potential trend change from bullish to bearish.",
                "strength": "Very High" if is_gold and pattern_strength > 70 else "High" if pattern_strength > 70 else "Medium",
                "signal": "sell",
                "reliability": pattern_strength
            }
    
    # Check for inverse head and shoulders
    troughs, _ = find_peaks(-price_data, distance=distance_param, prominence=prominence_param)
    
    for i in range(1, len(troughs) - 1):
        left_shoulder = price_data[troughs[i-1]]
        head = price_data[troughs[i]]
        right_shoulder = price_data[troughs[i+1]]
        
        shoulder_diff = abs(left_shoulder - right_shoulder)
        comparison_factor = (0.005 * np.mean(price_data) / 1500) if is_gold else 0.005
        
        if head < left_shoulder and head < right_shoulder and shoulder_diff < threshold_param:
            pattern_strength = min(100, int(100 * ((left_shoulder + right_shoulder) / 2 - head) / comparison_factor))
            
            # Gold has more reliable head and shoulders patterns
            if is_gold:
                pattern_strength = min(100, pattern_strength + 10)
                
            return {
                "name": "Inverse Head and Shoulders",
                "description": "A reversal pattern indicating a potential trend change from bearish to bullish.",
                "strength": "Very High" if is_gold and pattern_strength > 70 else "High" if pattern_strength > 70 else "Medium",
                "signal": "buy",
                "reliability": pattern_strength
            }
    
    return None

def detect_double_top_bottom(price_data, trend, is_gold=False):
    """
    Detect double top or double bottom patterns with enhanced sensitivity for gold charts.
    
    Args:
        price_data: Array of price points
        trend: String indicating the current trend
        is_gold: Boolean indicating if this is a gold chart
        
    Returns:
        Dictionary describing the pattern or None
    """
    # Adjust parameters based on chart type
    if is_gold:
        # Gold price has higher absolute values, so adjust accordingly
        distance_param = 15  # Slightly tighter for gold
        prominence_param = 0.0005 * np.mean(price_data) / 1500  # Scale with gold prices
        threshold_param = 0.0006 * np.mean(price_data) / 1500  # Gold has more precise tops/bottoms
    else:
        distance_param = 20
        prominence_param = 0.0005
        threshold_param = 0.0008
    
    # For double top
    if trend == "uptrend":
        peaks, _ = find_peaks(price_data, distance=distance_param, prominence=prominence_param)
        
        if len(peaks) >= 2:
            peak1 = price_data[peaks[-2]]
            peak2 = price_data[peaks[-1]]
            
            # Check if the two peaks are at similar levels
            if abs(peak1 - peak2) < threshold_param:
                comparison_factor = 0.001 * np.mean(price_data) / 1500 if is_gold else 0.001
                strength = min(100, int(100 * (1 - abs(peak1 - peak2) / comparison_factor)))
                
                # Gold double tops are highly reliable
                if is_gold:
                    strength = min(100, strength + 15)
                
                return {
                    "name": "Double Top",
                    "description": "A bearish reversal pattern indicating a potential change from uptrend to downtrend.",
                    "strength": "Very High" if is_gold and strength > 75 else "High" if strength > 75 else "Medium",
                    "signal": "sell",
                    "reliability": strength
                }
    
    # For double bottom
    if trend == "downtrend":
        troughs, _ = find_peaks(-price_data, distance=distance_param, prominence=prominence_param)
        
        if len(troughs) >= 2:
            trough1 = price_data[troughs[-2]]
            trough2 = price_data[troughs[-1]]
            
            # Check if the two troughs are at similar levels
            if abs(trough1 - trough2) < threshold_param:
                comparison_factor = 0.001 * np.mean(price_data) / 1500 if is_gold else 0.001
                strength = min(100, int(100 * (1 - abs(trough1 - trough2) / comparison_factor)))
                
                # Gold double bottoms are highly reliable
                if is_gold:
                    strength = min(100, strength + 15)
                    
                return {
                    "name": "Double Bottom",
                    "description": "A bullish reversal pattern indicating a potential change from downtrend to uptrend.",
                    "strength": "Very High" if is_gold and strength > 75 else "High" if strength > 75 else "Medium",
                    "signal": "buy",
                    "reliability": strength
                }
    
    return None

def detect_flag(price_data, trend, is_gold=False):
    """
    Detect flag patterns in the price data with enhanced sensitivity for gold charts.
    
    Args:
        price_data: Array of price points
        trend: String indicating the current trend
        is_gold: Boolean indicating if this is a gold chart
        
    Returns:
        Dictionary describing the pattern or None
    """
    # Flag patterns happen after a strong move (pole) followed by a consolidation against the trend
    
    # Gold often forms steeper, more reliable flags
    if is_gold:
        # Use smaller window size for gold as it forms flags more quickly
        window_size = min(15, len(price_data) // 5)
        
        # Thresholds for gold - percentage based for scaling
        bullish_threshold = 0.004  # 0.4% move
        bearish_threshold = -0.004  # -0.4% move
        correction_min = -0.002
        correction_max = 0.002
    else:
        # Standard parameters for other pairs
        window_size = min(20, len(price_data) // 4)
        bullish_threshold = 0.005
        bearish_threshold = -0.005
        correction_min = -0.003
        correction_max = 0.003
    
    # Calculate the rate of change for different segments
    roc_values = []
    for i in range(window_size, len(price_data), window_size):
        start = i - window_size
        end = i
        roc = (price_data[end-1] - price_data[start]) / price_data[start]
        roc_values.append(roc)
    
    # Need at least 2 segments to detect a flag
    if len(roc_values) < 2:
        return None
    
    # Check for bullish flag (strong up move, small down correction)
    if roc_values[0] > bullish_threshold and correction_min < roc_values[1] < 0:
        # Gold flags often have higher reliability
        strength_factor = 150 if is_gold else 100
        strength = min(100, int(abs(roc_values[0] / 0.01) * strength_factor))
        
        # Gold flags are stronger continuation signals
        if is_gold:
            return {
                "name": "Gold Bullish Flag",
                "description": "A high-reliability continuation pattern indicating a pause in the gold uptrend before continuing higher.",
                "strength": "Very High" if strength > 80 else "High",
                "signal": "buy",
                "reliability": strength
            }
        else:
            return {
                "name": "Bullish Flag",
                "description": "A continuation pattern indicating a pause in the uptrend before it continues higher.",
                "strength": "High" if strength > 70 else "Medium",
                "signal": "buy",
                "reliability": strength
            }
    
    # Check for bearish flag (strong down move, small up correction)
    if roc_values[0] < bearish_threshold and 0 < roc_values[1] < correction_max:
        # Gold flags often have higher reliability
        strength_factor = 150 if is_gold else 100
        strength = min(100, int(abs(roc_values[0] / 0.01) * strength_factor))
        
        # Gold flags are stronger continuation signals
        if is_gold:
            return {
                "name": "Gold Bearish Flag",
                "description": "A high-reliability continuation pattern indicating a pause in the gold downtrend before continuing lower.",
                "strength": "Very High" if strength > 80 else "High",
                "signal": "sell",
                "reliability": strength
            }
        else:
            return {
                "name": "Bearish Flag",
                "description": "A continuation pattern indicating a pause in the downtrend before it continues lower.",
                "strength": "High" if strength > 70 else "Medium",
                "signal": "sell",
                "reliability": strength
            }
    
    return None

def detect_triangle(price_data, is_gold=False):
    """
    Detect triangle patterns (symmetrical, ascending, descending) with gold-specific enhancements.
    
    Args:
        price_data: Array of price points
        is_gold: Boolean indicating if this is a gold chart
        
    Returns:
        Dictionary describing the pattern or None
    """
    # For this simplified implementation, we'll check for converging highs and lows
    
    half_length = len(price_data) // 2
    first_half = price_data[:half_length]
    second_half = price_data[half_length:]
    
    # Calculate the range (high - low) for each half
    first_range = max(first_half) - min(first_half)
    second_range = max(second_half) - min(second_half)
    
    # Gold triangle patterns have different convergence characteristics
    # they tend to break out more forcefully after converging
    convergence_threshold = 0.65 if is_gold else 0.7
    
    # Check if range is narrowing (triangle formation)
    if second_range < first_range * convergence_threshold:
        # Determine the type of triangle
        first_half_trend = detect_trend(first_half, is_gold)
        second_half_trend = detect_trend(second_half, is_gold)
        
        # Gold triangles have higher reliability than forex pairs
        reliability_boost = 20 if is_gold else 0
        
        if first_half_trend == "uptrend" and second_half_trend == "sideways":
            # Ascending triangle - even more reliable in gold
            return {
                "name": "Gold Ascending Triangle" if is_gold else "Ascending Triangle",
                "description": "A bullish continuation pattern with a flat top and rising bottom trendline. Gold tends to break strongly from this pattern.",
                "strength": "Very High" if is_gold else "Medium",
                "signal": "buy",
                "reliability": 85 if is_gold else 65
            }
        elif first_half_trend == "downtrend" and second_half_trend == "sideways":
            # Descending triangle - also reliable in gold
            return {
                "name": "Gold Descending Triangle" if is_gold else "Descending Triangle",
                "description": "A bearish continuation pattern with a flat bottom and declining top trendline. Gold tends to break sharply from this pattern.",
                "strength": "Very High" if is_gold else "Medium",
                "signal": "sell",
                "reliability": 85 if is_gold else 65
            }
        else:
            # Symmetrical triangle
            signal = "neutral"
            reliability = 60 + reliability_boost
            
            # For gold, symmetrical triangles often break in trend direction
            if is_gold:
                overall_trend = detect_trend(price_data, True)
                if overall_trend == "uptrend":
                    signal = "buy"
                    reliability += 10
                elif overall_trend == "downtrend":
                    signal = "sell"
                    reliability += 10
            
            return {
                "name": "Gold Symmetrical Triangle" if is_gold else "Symmetrical Triangle",
                "description": "A continuation pattern with converging trendlines, suggesting a period of consolidation before a breakout.",
                "strength": "High" if is_gold else "Medium",
                "signal": signal,
                "reliability": reliability
            }
    
    return None

def detect_support_resistance(price_data, predefined_levels, is_gold=False):
    """
    Identify if price is near support or resistance levels with enhanced gold-specific detection.
    
    Args:
        price_data: Array of price points
        predefined_levels: List of support/resistance levels
        is_gold: Boolean indicating if this is a gold chart
        
    Returns:
        List of dictionaries describing detected support/resistance patterns
    """
    patterns = []
    
    # Current price is the last point in the data
    current_price = price_data[-1]
    
    # Gold has stronger reactions at support/resistance, especially at round numbers
    if is_gold:
        # Proximity threshold for gold is wider in absolute terms but tighter in percentage terms
        # Gold is more volatile so we use a wider absolute range
        proximity_threshold = 15  # $15 for gold
        
        # Check for round number levels (psychological levels in gold)
        # These are very important in gold price action
        round_levels = []
        
        # Add common psychological levels for gold if not already in predefined levels
        for base_level in range(3000, 3500, 50):  # Check every $50 mark
            if not any(abs(base_level - level) < 5 for level in predefined_levels):
                round_levels.append(base_level)
        
        # Add the round levels to our analysis
        all_levels = list(predefined_levels) + round_levels
        
        # Check each level
        for level in all_levels:
            # Calculate distance from current price to the level
            distance = abs(current_price - level)
            
            # If price is near a level
            if distance < proximity_threshold:
                # Calculate strength based on proximity and if it's a round number
                is_round_number = level in round_levels or level % 50 == 0
                round_bonus = 10 if is_round_number else 0
                strength = min(100, int((proximity_threshold - distance) / proximity_threshold * 100) + round_bonus)
                
                if current_price > level:
                    # Price is above the level - potential support
                    reliability = strength
                    if is_round_number:
                        reliability = min(100, reliability + 5)  # Round numbers have higher reliability
                    
                    patterns.append({
                        "name": "Gold Support Level" if is_round_number else "Support Level",
                        "description": f"Price is currently testing a {'major psychological ' if is_round_number else ''}support level at ${level:.0f}.",
                        "strength": "Very High" if strength > 85 else "High" if strength > 70 else "Medium",
                        "signal": "buy",
                        "reliability": reliability
                    })
                else:
                    # Price is below the level - potential resistance
                    reliability = strength
                    if is_round_number:
                        reliability = min(100, reliability + 5)  # Round numbers have higher reliability
                    
                    patterns.append({
                        "name": "Gold Resistance Level" if is_round_number else "Resistance Level",
                        "description": f"Price is currently testing a {'major psychological ' if is_round_number else ''}resistance level at ${level:.0f}.",
                        "strength": "Very High" if strength > 85 else "High" if strength > 70 else "Medium",
                        "signal": "sell",
                        "reliability": reliability
                    })
    else:
        # Standard forex support/resistance detection
        proximity_threshold = 0.0005  # Standard threshold for forex pairs
        
        # Check if current price is near any support/resistance level
        for level in predefined_levels:
            # Calculate distance from current price to the level
            distance = abs(current_price - level)
            
            # If very close to a level
            if distance < proximity_threshold:
                # Determine if it's support or resistance
                if current_price > level:
                    # Price is above the level - potential support
                    strength = min(100, int((proximity_threshold - distance) / proximity_threshold * 100))
                    patterns.append({
                        "name": "Support Level",
                        "description": f"Price is currently testing a support level at {level:.5f}.",
                        "strength": "High" if strength > 80 else "Medium",
                        "signal": "buy",
                        "reliability": strength
                    })
                else:
                    # Price is below the level - potential resistance
                    strength = min(100, int((proximity_threshold - distance) / proximity_threshold * 100))
                    patterns.append({
                        "name": "Resistance Level",
                        "description": f"Price is currently testing a resistance level at {level:.5f}.",
                        "strength": "High" if strength > 80 else "Medium",
                        "signal": "sell",
                        "reliability": strength
                    })
    
    return patterns
